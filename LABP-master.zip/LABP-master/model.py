import torch
import torch.nn.functional as F
from utils import *
import cmath as c
from torch import nn
from ComplexUnet import ComplexUnet


class HQS_net(nn.Module):
    ''' HQS网络结构 '''
    def __init__(self, rho_X=0.1, in_channels=1, out_channels=1):
        nn.Module.__init__(self)
        self.net1 = HQSBlock(rho_X, in_channels, out_channels)
        self.net2 = HQSBlock(rho_X, in_channels, out_channels)

    def forward(self, mask, Y, Z_0):
        X, Z = self.net1(mask, Y, Z_0)
        X, Z = self.net2(mask, Y, Z)

        return X


class HQSBlock(nn.Module):
    ''' 单步HQS结构 '''
    def __init__(self, rho_X=0.1, in_channels=1, out_channels=1):
        nn.Module.__init__(self)
        self.imaging_layer = ImagingLayer(rho_X)
        self.denoising_layer = Denoise_Layer(in_channels, out_channels)

    def forward(self, mask, Y, Z_0):
        X = self.imaging_layer(mask, Y, Z_0)
        Z = self.denoising_layer(X)

        return X, Z

class ImagingLayer(nn.Module):
    ''' HQS的重构层 '''
    def __init__(self, ini_rho=0.1):
        super(ImagingLayer, self).__init__()
        self.rho = nn.Parameter(torch.Tensor([ini_rho]))

    def forward(self, mask, Y, Z):
        '''
        :param mask: M x N
        :param Z: batch_size x c x M x N
        :param Y: batch_size x c x M x N   pad后的hrrp
        :param A: batch_size x c x M x N
        :return: X: batch_size x c x M x N
        '''
        M = Z.size(2)
        N = Z.size(3)
        TmpMtx = (Y + 1/c.sqrt(M) * torch.fft.fft(self.rho*Z, M, 2)) / (mask + self.rho*torch.ones(M,N).cuda())
        X = c.sqrt(M) * torch.fft.ifft(TmpMtx, M, 2)
        return X


class Denoise_Layer(nn.Module):
    ''' HQS的降噪层 '''
    def __init__(self, in_channels, out_channels):
        super(Denoise_Layer, self).__init__()
        # self.rho = nn.Parameter(torch.Tensor([ini_rho]))
        # self.lam = nn.Parameter(torch.Tensor([ini_lam]))
        self.denoiser = ComplexUnet(in_channels, out_channels)

    def forward(self, X):
        '''
        :param X: batch_size x M x N
        :param A: batch_size x M x N
        :return: Z: batch_size x M x N
        '''
        Z = self.denoiser(X)
        return Z

# class ComplexNet(nn.Module):
#
#     def __init__(self):
#         super(ComplexNet, self).__init__()
#         self.conv1 = ComplexConv2d(1, 1, 5, 1)
#         self.bn = ComplexBatchNorm2d(10)
#         self.conv2 = ComplexConv2d(10, 20, 5, 1)
#         self.fc1 = ComplexLinear(4 * 4 * 20, 500)
#         self.fc2 = ComplexLinear(500, 10)
#
#     def forward(self, x):
#         x = self.conv1(x)
#         x = complex_relu(x)
#         x = complex_max_pool2d(x, 2, 2)
#         x = self.bn(x)
#         x = self.conv2(x)
#         x = complex_relu(x)
#         x = complex_max_pool2d(x, 2, 2)
#         x = x.view(-1, 4 * 4 * 20)
#         x = self.fc1(x)
#         x = complex_relu(x)
#         x = self.fc2(x)
#         x = x.abs()
#         x = F.log_softmax(x, dim=1)
#         return x

def mySoftThreshod(X, thresh):
    '''
    :param X: batch_size x M x N
    :param thresh: real scalar
    :return: re: batch_size x M x N
    '''
    re = (X+0.00001)/torch.abs(X+0.00001) * torch.max( torch.abs(X) - thresh, torch.zeros(X.shape).cuda() )
    return re

class MetaLearner(nn.Module):
    ''' 全连接网络元学习器 '''
    def __init__(self, n):
        nn.Module.__init__(self)
        self.layer1 = torch.nn.Linear(4*n-3, 4*n-3)
        self.layer2 = torch.nn.Linear(4*n-3, 4*n-3)
        self.layer3 = torch.nn.Linear(4*n-3, 4*n-3)

    def forward(self, grad_x):
        grad_x = F.relu(self.layer1(grad_x))
        grad_x = F.relu(self.layer2(grad_x))
        grad_x = torch.tanh(self.layer3(grad_x))
        return grad_x


class MetaLearner_AF(nn.Module):
    ''' 全连接网络元学习器 '''
    def __init__(self, n):
        nn.Module.__init__(self)
        self.layer1 = torch.nn.Linear(5*n-4, 5*n-4)
        self.layer2 = torch.nn.Linear(5*n-4, 5*n-4)
        self.layer3 = torch.nn.Linear(5*n-4, 5*n-4)

    def forward(self, grad_x):
        grad_x = F.relu(self.layer1(grad_x))
        grad_x = F.relu(self.layer2(grad_x))
        grad_x = torch.tanh(self.layer3(grad_x))
        return grad_x


class XLayer(nn.Module):
    ''' ADMM的重构层 '''
    def __init__(self, ini_rho=0.1):
        super(XLayer, self).__init__()
        self.rho = nn.Parameter(torch.Tensor([ini_rho]))

    def forward(self, mask, Y, Z, A):
        '''
        :param mask: M x N
        :param Z: batch_size x M x N
        :param Y: batch_size x M x N   pad后的hrrp
        :param A: batch_size x M x N
        :return: X: batch_size x M x N
        '''
        M = Z.size(1)
        N = Z.size(2)
        a = 1/c.sqrt(M) * torch.fft.fft(self.rho * Z - A, M, 1)
        a = (Y + a.unsqueeze(1))
        TmpMtx = a / (mask + self.rho*torch.ones(M,N).cuda())
        X = c.sqrt(M) * torch.fft.ifft(TmpMtx.squeeze(1), M, 1)
        return X


class ZLayer(nn.Module):
    ''' ADMM的降噪层 '''
    def __init__(self, ini_rho=0.1, ini_lam=0.01):
        super(ZLayer, self).__init__()
        self.rho = nn.Parameter(torch.Tensor([ini_rho]))
        self.lam = nn.Parameter(torch.Tensor([ini_lam]))

    def forward(self, X, A):
        '''
        :param X: batch_size x M x N
        :param A: batch_size x M x N
        :return: Z: batch_size x M x N
        '''
        Z = mySoftThreshod(X+A/self.rho, self.lam/self.rho)
        return Z


class ALayer(nn.Module):
    ''' ADMM的乘子更新层 '''
    def __init__(self, ini_rho=0.1):
        super(ALayer, self).__init__()
        self.rho = nn.Parameter(torch.Tensor([ini_rho]))

    def forward(self, X, Z, A_0):
        '''
        :param X: batch_size x M x N
        :param Z: batch_size x M x N
        :param A_0: batch_size x M x N
        :return: A: batch_size x M x N
        '''
        A = A_0 + self.rho*(X-Z)
        return A


class ADMMBlock(nn.Module):
    ''' 单步ADMM结构 '''
    def __init__(self, rho_X=0.1, rho_Z=0.1, lam_Z=0.01, rho_A=0.1):
        nn.Module.__init__(self)
        self.x_layer = XLayer(rho_X)
        self.z_layer = ZLayer(rho_Z, lam_Z)
        self.a_layer = ALayer(rho_A)

    def forward(self, mask, Y, Z_0, A_0):
        X = self.x_layer(mask, Y, Z_0, A_0)
        Z = self.z_layer(X, A_0)
        A = self.a_layer(X, Z, A_0)
        return X, Z, A


class ADMM_net(nn.Module):
    ''' ADMM网络结构 '''
    def __init__(self, rho_X=0.1, rho_Z=0.1, lam_Z=0.01, rho_A=0.1):
        nn.Module.__init__(self)
        self.net1 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net2 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net3 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net4 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net5 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net6 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net7 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net8 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net9 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net10 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net11 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net12 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net13 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net14 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net15 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net16 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net17 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net18 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net19 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)
        self.net20 = ADMMBlock(rho_X, rho_Z, lam_Z, rho_A)


    def forward(self, mask, Y, Z_0, A_0):
        X, Z, A = self.net1(mask, Y, Z_0, A_0)
        X, Z, A = self.net2(mask, Y, Z, A)
        X, Z, A = self.net3(mask, Y, Z, A)
        X, Z, A = self.net4(mask, Y, Z, A)
        X, Z, A = self.net5(mask, Y, Z, A)
        X, Z, A = self.net6(mask, Y, Z, A)
        X, Z, A = self.net7(mask, Y, Z, A)
        X, Z, A = self.net8(mask, Y, Z, A)
        X, Z, A = self.net9(mask, Y, Z, A)
        X, Z, A = self.net10(mask, Y, Z, A)
        X, Z, A = self.net11(mask, Y, Z, A)
        X, Z, A = self.net12(mask, Y, Z, A)
        X, Z, A = self.net13(mask, Y, Z, A)
        X, Z, A = self.net14(mask, Y, Z, A)
        X, Z, A = self.net15(mask, Y, Z, A)
        X, Z, A = self.net16(mask, Y, Z, A)
        X, Z, A = self.net17(mask, Y, Z, A)
        X, Z, A = self.net18(mask, Y, Z, A)
        X, Z, A = self.net19(mask, Y, Z, A)
        X, Z, A = self.net20(mask, Y, Z, A)

        return X
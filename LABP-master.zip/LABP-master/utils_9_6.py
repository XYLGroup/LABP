import numpy as np
import random
import matplotlib.pyplot as plt
import torch
import pickle
import os
import xlwt
import scipy.io as sio
import math
import torch.nn.functional as F

import torch
import torch.nn as nn
from torch.autograd import Variable
from math import exp


device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
# device = 'cpu'
# print("Device_use:", device)




def DFT(sig):
    N = sig.size
    V = np.array([[np.exp(-1j*2*np.pi*v*y/N) for v in range(N)] for y in range(N)])
    return sig.dot(V)


def FFT_np(x):
    N = x.shape[1] # 只需考虑第二个维度，然后在第一个维度循环
    if N % 2 > 0:
        raise ValueError("size of x must be a power of 2")
    elif N <= 8:  # this cutoff should be optimized
        return np.array([DFT(x[i,:]) for i in range(x.shape[0])])
    else:
        X_even = FFT_np(x[:,::2])
        X_odd = FFT_np(x[:,1::2])
        factor = np.array([np.exp(-2j * np.pi * np.arange(N) / N) for i in range(x.shape[0])])
        return np.hstack([X_even + np.multiply(factor[:,:int(N/2)],X_odd),
                               X_even + np.multiply(factor[:,int(N/2):],X_odd)])

def IFFT_np1(x):
    N = x.shape[1] # 只需考虑第二个维度，然后在第一个维度循环
    if N % 2 > 0:
        raise ValueError("size of x must be a power of 2")
    elif N <= 8:  # this cutoff should be optimized
        return np.array([DFT(x[i,:]) for i in range(x.shape[0])])
    else:
        X_even = IFFT_np1(x[:,::2])
        X_odd = IFFT_np1(x[:,1::2])
        factor = np.array([np.exp(2j * np.pi * np.arange(N) / N) for i in range(x.shape[0])])
        return (np.hstack([X_even + np.multiply(factor[:,:int(N/2)],X_odd),
                               X_even + np.multiply(factor[:,int(N/2):],X_odd)]))

def IFFT_np(x):
    return IFFT_np1(x)/x.shape[1]


def DFT_tc(sig):

    N = sig.shape[0]
    # V = np.array([[np.exp(-1j * 2 * np.pi * v * y / N) for v in range(N)] for y in range(N)])
    V_real = torch.tensor(([[torch.cos(torch.tensor(2 * math.pi * v * y / N)) for v in range(N)] for y in range(N)])).unsqueeze(-1)
    V_imag = torch.tensor(([[torch.sin(torch.tensor(-2 * math.pi * v * y / N)) for v in range(N)] for y in range(N)])).unsqueeze(-1)
    V_tc = torch.cat((V_real, V_imag), 2).to(device)

    return tc_mul(sig, V_tc)


def IFFT_tc1(x):
    N = x.shape[1] # 只需考虑第二个维度，然后在第一个维度循环
    if N % 2 > 0:
        raise ValueError("size of x must be a power of 2")
    elif N <= 8:  # this cutoff should be optimized
        return torch.stack([(DFT_tc(x[i, :, :])) for i in range(x.shape[0])])


    else:
        X_even = IFFT_tc1(x[:,::2,:])
        X_odd = IFFT_tc1(x[:,1::2,:])

        # factor = torch.tensor([torch.exp(2j * torch.pi * torch.arange(N) / N) for i in range(x.shape[0])])
        # factor = np.array([np.exp(2j * np.pi * np.arange(N) / N) for i in range(x.shape[0])])
        factor_real = torch.stack([torch.cos(2 * math.pi * torch.arange(N) / N) for i in range(x.shape[0])]).unsqueeze(-1)
        factor_imag = torch.stack([torch.sin(2 * math.pi * torch.arange(N) / N) for i in range(x.shape[0])]).unsqueeze(-1)
        factor_tc = torch.cat((factor_real, factor_imag), 2).to(device)
        return (torch.hstack([X_even + tc_dot_mul(factor_tc[:,:int(N/2),:], X_odd),
                               X_even + tc_dot_mul(factor_tc[:,int(N/2):,:], X_odd)]))


def IFFT_tc(x):
    x = x.to(device)
    return IFFT_tc1(x) / x.shape[1]


def IFFT_SHIFT2_tc(img):
    M = img.shape[0]
    N = img.shape[1]
    M = int(M/2)
    N = int(N/2)
    # return img[M:, N:]
    return torch.vstack((torch.hstack((img[:M,:N], img[:M,N:])), torch.hstack((img[M:,:N], img[M:,N:]))))


def FFT_SHIFT2_np(img):
    M,N = img.shape
    M = int(M/2)
    N = int(N/2)
    # return img[M:, N:]
    return np.vstack((np.hstack((img[:M,N:],img[:M,:N])), np.hstack((img[M:,N:],img[M:,:N]))))

def IFFT_SHIFT2_np(img):
    M,N = img.shape
    M = int(M/2)
    N = int(N/2)
    # return img[M:, N:]
    return np.vstack(( np.hstack((img[M:,:N], img[M:,N:])),  np.hstack((img[:M,:N], img[:M,N:]))  ))

def overturn(hrrp):
    hrrp_overturned = np.zeros_like(hrrp)
    N = hrrp.shape[0]
    for ii in range(N):
        hrrp_overturned[:, ii] = hrrp[:, N - ii - 1]

    return hrrp_overturned

def hrrp_crop(hrrp):
    M = hrrp.shape[0]
    N = hrrp.shape[1]
    if N % 2 > 0 or M % 2 > 0:
        hrrp = hrrp[0:(M//2)*2,0:(N//2)*2]

    return hrrp

def calculate_psnr(img1, img2, is_kernel=False):
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(1.0 / math.sqrt(mse)) if is_kernel else 20 * math.log10(255.0 / math.sqrt(mse))

def plot_kernel(gt_k_np, out_k_np, savepath):
    plt.clf()
    f, ax = plt.subplots(1, 2, figsize=(6, 4), squeeze=False)
    im = ax[0, 0].imshow(gt_k_np, vmin=0, vmax=gt_k_np.max())
    plt.colorbar(im, ax=ax[0, 0])
    im = ax[0, 1].imshow(out_k_np, vmin=0, vmax=out_k_np.max())
    plt.colorbar(im, ax=ax[0, 1])
    ax[0, 0].set_title('GT')
    ax[0, 1].set_title('PSNR: {:.2f}'.format(calculate_psnr(gt_k_np, out_k_np, True)))

    plt.savefig(savepath)


def save_final_kernel_png(k, conf, gt_kernel, step=''):
    """saves the final kernel and the analytic kernel to the results folder"""
    os.makedirs(os.path.join(conf.output_dir_path), exist_ok=True)
    savepath_mat = os.path.join(conf.output_dir_path, '%s.mat' % conf.img_name)
    savepath_png = os.path.join(conf.output_dir_path, '%s_kernel.png' % conf.img_name)
    if step != '':
        savepath_mat = savepath_mat.replace('.mat', '_{}.mat'.format(step))
        savepath_png = savepath_png.replace('.png', '_{}.png'.format(step))

    sio.savemat(savepath_mat, {'Kernel': k})
    plot_kernel(gt_kernel, k, savepath_png)

def plot_mat(mat, path, filename):
    plt.clf()
    f, ax = plt.subplots(1, 1, figsize=(6, 4), squeeze=False)
    im = ax[0, 0].imshow(mat, vmin=0, vmax=mat.max())
    plt.colorbar(im, ax=ax[0, 0])
    # im = ax[0, 1].imshow(out_k_np, vmin=0, vmax=out_k_np.max())
    # plt.colorbar(im, ax=ax[0, 1])
    ax[0, 0].set_title(filename)
    # ax[0, 1].set_title('PSNR: {:.2f}'.format(calculate_psnr(gt_k_np, out_k_np, True)))

    plt.savefig(path)

def save_imagesc_mat2png(mat, path, filename):
    os.makedirs(os.path.join(path), exist_ok=True)
    sio.savemat(path + filename + ".mat", {'hrrp': mat})
    plot_mat(mat, path + filename + ".png", filename)


def progress(arg, percent):
	if arg > 1:
		arg = 1
	# 设计进度条和百分比

	image = int(50 * arg) * '#'
	# percent = str(int(arg * 100)) + '%'
	# 打印进度条
	print('\033[1;31m ISAR imaging Process: \r[%-50s] %s \033[0m' % ( image, percent), end='')
	# 下载完成判断并提示
	if arg == 1:
		print(' ')


def tc2tensor(A):

    if A.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        B_tensor = A_real + 1j * A_imag

    return B_tensor

def tensor2tc(A):

    if A.ndim == 2:

        B_real = A.real.unsqueeze(-1)
        B_imag = A.imag.unsqueeze(-1)

        B_tc = torch.cat((B_real, B_imag), 2)
        B_tc = B_tc.type(torch.float64)

    return B_tc

def tc_abs(A):
    if A.ndim == 3:
        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        A_abs = A_real * A_real + A_imag * A_imag

    return A_abs**(0.5)


def tc_det2(A):
    if A.ndim == 3 and A.shape[0] == 2 and A.shape[1] == 2:
        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        A_det_real = A_real[0][0] * A_real[1][1] - A_real[0][1] * A_real[1][0] + A_imag[0][1] * A_imag[1][0]
        A_det_imag = 0 - A_real[0][1] * A_imag[1][0] - A_real[1][0] * A_imag[0][1]

        A_det_tc = torch.cat((A_det_real.unsqueeze(-1), A_det_imag.unsqueeze(-1)), 0)

    return A_det_tc

def compare_tc_np(tc, np):
    np_tc = torch.from_numpy(np)
    np_tc_real = np_tc.real.unsqueeze(-1)
    np_tc_imag = np_tc.imag.unsqueeze(-1)
    np_tc = torch.cat((np_tc_real, np_tc_imag), -1)

    return torch.sum(tc - np_tc)

def save_variable(v,filename):
  f=open(filename,'wb')
  pickle.dump(v,f)
  f.close()
  return filename


def load_variavle(filename):
  f=open(filename,'rb')
  r=pickle.load(f)
  f.close()
  return r


def tc_det(A):

    if A.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        A_c = A_real + 1j * A_imag

        A_det = torch.linalg.det(A_c)

        A_det_real = A_det.real.unsqueeze(-1)
        A_det_imag = A_det.imag.unsqueeze(-1)
        A_det_tc = torch.cat((A_det_real, A_det_imag), 0)

        A_det_tc = A_det_tc.type(torch.float64)


    return A_det_tc

def tc_log(A):

    if A.ndim == 1:
        A_real = A[0]
        A_imag = A[1]

        A_c = A_real + 1j * A_imag

        A_log = torch.log(A_c)

        A_log_real = A_log.real.unsqueeze(-1)
        A_log_imag = A_log.imag.unsqueeze(-1)
        A_log_tc = torch.cat((A_log_real, A_log_imag), 0)

        A_log_tc = A_log_tc.type(torch.float64)


    if A.ndim == 3:
        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        A_c = A_real + 1j * A_imag

        A_log = torch.log(A_c)

        A_log_real = A_log.real.unsqueeze(-1)
        A_log_imag = A_log.imag.unsqueeze(-1)
        A_log_tc = torch.cat((A_log_real, A_log_imag), 2)

        A_log_tc = A_log_tc.type(torch.float64)


    return A_log_tc


def tc_inv(A):

    if A.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        A_c = A_real + 1j * A_imag
        A_inv = torch.linalg.inv(A_c)

        A_inv_real = A_inv.real.unsqueeze(-1)
        A_inv_imag = A_inv.imag.unsqueeze(-1)
        A_inv_tc = torch.cat((A_inv_real, A_inv_imag), 2)

        A_inv_tc = A_inv_tc.type(torch.float64)

    return A_inv_tc

def tc_pinv(A):

    if A.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        A_c = A_real + 1j * A_imag
        A_pinv = torch.linalg.pinv(A_c)

        A_pinv_real = A_pinv.real.unsqueeze(-1)
        A_pinv_imag = A_pinv.imag.unsqueeze(-1)
        A_pinv_tc = torch.cat((A_pinv_real, A_pinv_imag), 2)

        A_pinv_tc = A_pinv_tc.type(torch.float64)

    return A_pinv_tc


def tc_dot_mul(A, B):

    if A.dtype != B.dtype:

        A = A.type(torch.float64)
        B = B.type(torch.float64)

    if A.ndim == 3 and B.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]
        B_real = B[:, :, 0]
        B_imag = B[:, :, 1]

        C_real = A_real * B_real - A_imag * B_imag
        C_imag = A_real * B_imag + A_imag * B_real

        C = torch.cat((C_real.unsqueeze(-1), C_imag.unsqueeze(-1)), 2)


    return C


def tc_mul(A, B):

    if A.dtype != B.dtype:

        A = A.type(torch.float64)
        B = B.type(torch.float64)

    if A.ndim == 3 and B.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]
        B_real = B[:, :, 0]
        B_imag = B[:, :, 1]

        C_real = torch.mm(A_real, B_real) - torch.mm(A_imag, B_imag)
        C_imag = torch.mm(A_real, B_imag) + torch.mm(A_imag, B_real)

        C = torch.cat((C_real.unsqueeze(-1), C_imag.unsqueeze(-1)), 2)

    if A.ndim == 2 and B.ndim == 3:


        A_real = A[:, 0]
        A_imag = A[:, 1]
        B_real = B[:, :, 0]
        B_imag = B[:, :, 1]

        C_real = (A_real @ B_real - A_imag @ B_imag).unsqueeze(-1)
        C_imag = (A_real @ B_imag + A_imag @ B_real).unsqueeze(-1)

        C = torch.cat((C_real, C_imag), 1)

    # if A.ndim == 2 and B.ndim == 2:
    #
    #     C_real = torch.mm(A.real, B.real) - torch.mm(A.imag, B.imag)
    #     C_imag = torch.mm(A.real, B.imag) + torch.mm(A.imag, B.real)
    #
    #     C = C_real + 1j * C_imag

    if A.ndim == 1 and B.ndim == 1:
        A_real = A[0]
        A_imag = A[1]
        B_real = B[0]
        B_imag = B[1]

        C_real = A_real * B_real - A_imag * B_imag
        C_imag = A_real * B_imag + A_imag * B_real

        C = torch.cat((C_real.unsqueeze(-1), C_imag.unsqueeze(-1)), 0)

    return C

def tc_T(A):
    if A.ndim == 3:

        # A_T = torch.zeros(A.shape[1], A.shape[0], A.shape[2])
        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]
        A_T = torch.cat(((A_real.T).unsqueeze(-1), (A_imag.T).unsqueeze(-1)), 2)



    if A.ndim == 2:
        # A_T = torch.zeros(A.shape[1], A.shape[0], dtype=torch.complex128)
        A_T = A.T

    return A_T

def tc_CT(A):
    if A.ndim == 3:
        # A_CT = torch.zeros(A.shape[0], A.shape[2], A.shape[1], dtype=torch.complex128)
        A_T = tc_T(A)

        Imag = torch.zeros(A_T.shape[0], A_T.shape[1], 2).to(device)

        Imag[:, :, 1] = A_T[:, :, 1]

        A_CT = A_T - 2 * Imag

    if A.ndim == 2:
        # A_CT = torch.zeros(A.shape[1], A.shape[0], dtype=torch.complex128)
        A_T = tc_T(A)
        A_CT = A_T.real - 1j * A_T.imag

    if A.ndim == 1:
        A_real = A[0]
        A_imag = A[1]

        A_CT_real = A_real
        A_CT_imag = 0 - A_imag

        A_CT = torch.cat((A_CT_real.unsqueeze(-1), A_CT_imag.unsqueeze(-1)), 0)


    return A_CT

def tc_trace(A):

    if A.ndim == 3:

        A_real = A[:, :, 0]
        A_imag = A[:, :, 1]

        trace_real = torch.trace(A_real)
        trace_imag = torch.trace(A_imag)

        trace = torch.cat((trace_real.unsqueeze(-1), trace_imag.unsqueeze(-1)), 0)

    return trace



def skip(
        num_input_channels=2, num_output_channels=3,
        num_channels_down=[16, 32, 64, 128, 128], num_channels_up=[16, 32, 64, 128, 128],
        num_channels_skip=[4, 4, 4, 4, 4],
        filter_size_down=3, filter_size_up=3, filter_skip_size=1,
        need_sigmoid=True, need_bias=True,
        pad='zero', upsample_mode='nearest', downsample_mode='stride', act_fun='LeakyReLU',
        need1x1_up=True):
    """ Network of DIP: Assembles encoder-decoder with skip connections.

    Arguments:
        act_fun: Either string 'LeakyReLU|Swish|ELU|none' or module (e.g. nn.ReLU)
        pad (string): zero|reflection (default: 'zero')
        upsample_mode (string): 'nearest|bilinear' (default: 'nearest')
        downsample_mode (string): 'stride|avg|max|lanczos2' (default: 'stride')

    """
    assert len(num_channels_down) == len(num_channels_up) == len(num_channels_skip)

    n_scales = len(num_channels_down)

    if not (isinstance(upsample_mode, list) or isinstance(upsample_mode, tuple)):
        upsample_mode = [upsample_mode] * n_scales

    if not (isinstance(downsample_mode, list) or isinstance(downsample_mode, tuple)):
        downsample_mode = [downsample_mode] * n_scales

    if not (isinstance(filter_size_down, list) or isinstance(filter_size_down, tuple)):
        filter_size_down = [filter_size_down] * n_scales

    if not (isinstance(filter_size_up, list) or isinstance(filter_size_up, tuple)):
        filter_size_up = [filter_size_up] * n_scales

    last_scale = n_scales - 1

    # cur_depth = None

    model = nn.Sequential()  # this is a pointer
    model_tmp = model

    input_depth = num_input_channels
    for i in range(len(num_channels_down)):

        deeper = nn.Sequential()  # encoder; decoder is directly in model_tmp
        skip = nn.Sequential()  # skip

        if num_channels_skip[i] != 0:
            model_tmp.add(Concat(1, skip, deeper))  # cat encoded feature and shortcut's along channel
        else:
            model_tmp.add(deeper)

        model_tmp.add(bn(num_channels_skip[i] + (num_channels_up[i + 1] if i < last_scale else num_channels_down[i])))

        if num_channels_skip[i] != 0:  # skip=conv+bn+act
            skip.add(conv(input_depth, num_channels_skip[i], filter_skip_size, bias=need_bias, pad=pad))
            skip.add(bn(num_channels_skip[i]))
            skip.add(act(act_fun))

        # skip.add(Concat(2, GenNoise(nums_noise[i]), skip_part))

        deeper.add(conv(input_depth, num_channels_down[i], filter_size_down[i], 2, bias=need_bias, pad=pad,
                        downsample_mode=downsample_mode[i]))
        deeper.add(bn(num_channels_down[i]))
        deeper.add(act(act_fun))

        # only difference from original
        if i > 1:
            deeper.add(NONLocalBlock2D(in_channels=num_channels_down[i]))

        deeper.add(conv(num_channels_down[i], num_channels_down[i], filter_size_down[i], bias=need_bias, pad=pad))
        deeper.add(bn(num_channels_down[i]))
        deeper.add(act(act_fun))

        deeper_main = nn.Sequential()

        if i == len(num_channels_down) - 1:
            # The deepest, directly cat deeper and skip
            k = num_channels_down[i]
        else:
            deeper.add(deeper_main)  # add an entrance for next level, will be save by model_tmp
            k = num_channels_up[i + 1]  # the output from next-level decoder

        deeper.add(nn.Upsample(scale_factor=2, mode=upsample_mode[i], align_corners=True))

        model_tmp.add(conv(num_channels_skip[i] + k, num_channels_up[i], filter_size_up[i], 1, bias=need_bias,
                           pad=pad))  # encoder+skip
        model_tmp.add(bn(num_channels_up[i]))
        model_tmp.add(act(act_fun))

        if need1x1_up:
            model_tmp.add(conv(num_channels_up[i], num_channels_up[i], 1, bias=need_bias, pad=pad))
            model_tmp.add(bn(num_channels_up[i]))
            model_tmp.add(act(act_fun))

        input_depth = num_channels_down[i]
        model_tmp = deeper_main

    model.add(conv(num_channels_up[0], num_output_channels, 1, bias=need_bias, pad=pad))
    if need_sigmoid:
        model.add(nn.Sigmoid())

    return model

def gaussian(window_size, sigma):
    gauss = torch.Tensor([exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)])
    return gauss / gauss.sum()


def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = Variable(_2D_window.expand(channel, 1, window_size, window_size).contiguous())
    return window


def _ssim(img1, img2, window, window_size, channel, size_average=True):
    mu1 = F.conv2d(img1, window, padding=window_size // 2, groups=channel)
    mu2 = F.conv2d(img2, window, padding=window_size // 2, groups=channel)

    mu1_list = mu1.tolist()
    mu2_list = mu2.tolist()

    # if len(mu1_list[0][0][0]) > len(mu2_list[0][0][0]):
    #     mu1 = mu1[:, :, :, 0:len(mu2_list[0][0][0])]
    # elif len(mu1_list[0][0][0]) < len(mu2_list[0][0][0]):
    #     mu2 = mu2[:, :, :, 0:len(mu1_list[0][0][0])]
    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)

    mu1_mu2 = mu1 * mu2

    sigma1_sq = F.conv2d(img1 * img1, window, padding=window_size // 2, groups=channel) - mu1_sq
    sigma2_sq = F.conv2d(img2 * img2, window, padding=window_size // 2, groups=channel) - mu2_sq
    sigma12 = F.conv2d(img1 * img2, window, padding=window_size // 2, groups=channel) - mu1_mu2

    C1 = 0.01 ** 2
    C2 = 0.03 ** 2

    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)


class SSIM(torch.nn.Module):
    def __init__(self, window_size=11, size_average=True):
        super(SSIM, self).__init__()
        self.window_size = window_size
        self.size_average = size_average
        self.channel = 1
        self.window = create_window(window_size, self.channel)

    def forward(self, img1, img2):
        (_, channel, _, _) = img1.size()

        if channel == self.channel and self.window.data.type() == img1.data.type():
            window = self.window
        else:
            window = create_window(self.window_size, channel)

            if img1.is_cuda:
                window = window.cuda(img1.get_device())
            window = window.type_as(img1)

            self.window = window
            self.channel = channel

        return _ssim(img1, img2, window, self.window_size, channel, self.size_average)



def fill_noise(x, noise_type):
    """Fills tensor `x` with noise of type `noise_type`."""
    torch.manual_seed(1)
    if noise_type == 'u':
        x.uniform_()
    elif noise_type == 'n':
        x.normal_()
    else:
        assert False


def np_to_torch(img_np):
    '''Converts image in numpy.array to torch.Tensor.

    From C x W x H [0..1] to  C x W x H [0..1]
    '''
    return torch.from_numpy(img_np)[None, :]

def get_noise(input_depth, method, spatial_size, noise_type='u', var=1. / 10):
    """Returns a pytorch.Tensor of size (1 x `input_depth` x `spatial_size[0]` x `spatial_size[1]`)
    initialized in a specific way.
    Args:
        input_depth: number of channels in the tensor
        method: `noise` for fillting tensor with noise; `meshgrid` for np.meshgrid
        spatial_size: spatial size of the tensor to initialize
        noise_type: 'u' for uniform; 'n' for normal
        var: a factor, a noise will be multiplicated by. Basically it is standard deviation scaler.
    """
    if isinstance(spatial_size, int):
        spatial_size = (spatial_size, spatial_size)
    if method == 'noise':
        shape = [1, input_depth, spatial_size[0], spatial_size[1]]
        net_input = torch.zeros(shape)

        fill_noise(net_input, noise_type)
        net_input *= var
    elif method == 'meshgrid':
        assert input_depth == 2
        X, Y = np.meshgrid(np.arange(0, spatial_size[1]) / float(spatial_size[1] - 1),
                           np.arange(0, spatial_size[0]) / float(spatial_size[0] - 1))
        meshgrid = np.concatenate([X[None, :], Y[None, :]])
        net_input = np_to_torch(meshgrid)
    else:
        assert False

    return net_input


def add_module(self, module):
    self.add_module(str(len(self) + 1), module)


torch.nn.Module.add = add_module


class Concat(nn.Module):
    def __init__(self, dim, *args):
        super(Concat, self).__init__()
        self.dim = dim

        for idx, module in enumerate(args):
            self.add_module(str(idx), module)

    def forward(self, input):
        inputs = []
        for module in self._modules.values():
            inputs.append(module(input))

        inputs_shapes2 = [x.shape[2] for x in inputs]
        inputs_shapes3 = [x.shape[3] for x in inputs]

        if np.all(np.array(inputs_shapes2) == min(inputs_shapes2)) and np.all(
                np.array(inputs_shapes3) == min(inputs_shapes3)):
            inputs_ = inputs
        else:
            target_shape2 = min(inputs_shapes2)
            target_shape3 = min(inputs_shapes3)

            inputs_ = []
            for inp in inputs:
                diff2 = (inp.size(2) - target_shape2) // 2
                diff3 = (inp.size(3) - target_shape3) // 2
                inputs_.append(inp[:, :, diff2: diff2 + target_shape2, diff3:diff3 + target_shape3])

        return torch.cat(inputs_, dim=self.dim)

    def __len__(self):
        return len(self._modules)


class GenNoise(nn.Module):
    def __init__(self, dim2):
        super(GenNoise, self).__init__()
        self.dim2 = dim2

    def forward(self, input):
        a = list(input.size())
        a[1] = self.dim2
        # print (input.data.type())

        b = torch.zeros(a).type_as(input.data)
        b.normal_()

        x = torch.autograd.Variable(b)

        return x


class Swish(nn.Module):
    """
        The hype was so huge that I could not help but try it
    """

    def __init__(self):
        super(Swish, self).__init__()
        self.s = nn.Sigmoid()

    def forward(self, x):
        return x * self.s(x)


def act(act_fun='LeakyReLU'):
    '''
        Either string defining an activation function or module (e.g. nn.ReLU)
    '''
    if isinstance(act_fun, str):
        if act_fun == 'LeakyReLU':
            return nn.LeakyReLU(0.2, inplace=True)
        elif act_fun == 'Swish':
            return Swish()
        elif act_fun == 'ELU':
            return nn.ELU()
        elif act_fun == 'none':
            return nn.Sequential()
        else:
            assert False
    else:
        return act_fun()


def bn(num_features):
    return nn.BatchNorm2d(num_features)


def conv(in_f, out_f, kernel_size, stride=1, bias=True, pad='zero', downsample_mode='stride'):
    downsampler = None
    if stride != 1 and downsample_mode != 'stride':

        if downsample_mode == 'avg':
            downsampler = nn.AvgPool2d(stride, stride)
        elif downsample_mode == 'max':
            downsampler = nn.MaxPool2d(stride, stride)
        else:
            assert False

        stride = 1

    padder = None
    to_pad = int((kernel_size - 1) / 2)
    if pad == 'reflection':
        padder = nn.ReflectionPad2d(to_pad)
        to_pad = 0
    convolver = nn.Conv2d(in_f, out_f, kernel_size, stride, padding=to_pad, bias=bias)

    layers = filter(lambda x: x is not None, [padder, convolver, downsampler])
    return nn.Sequential(*layers)

class _NonLocalBlockND(nn.Module):
    def __init__(self, in_channels, inter_channels=None, dimension=3, sub_sample=True, bn_layer=True):
        super(_NonLocalBlockND, self).__init__()

        assert dimension in [1, 2, 3]

        self.dimension = dimension
        self.sub_sample = sub_sample

        self.in_channels = in_channels
        self.inter_channels = inter_channels

        if self.inter_channels is None:
            self.inter_channels = in_channels // 2
            if self.inter_channels == 0:
                self.inter_channels = 1

        if dimension == 3:
            conv_nd = nn.Conv3d
            max_pool_layer = nn.MaxPool3d(kernel_size=(1, 2, 2))
            bn = nn.BatchNorm3d
        elif dimension == 2:
            conv_nd = nn.Conv2d
            max_pool_layer = nn.MaxPool2d(kernel_size=(2, 2))
            bn = nn.BatchNorm2d
        else:
            conv_nd = nn.Conv1d
            max_pool_layer = nn.MaxPool1d(kernel_size=(2))
            bn = nn.BatchNorm1d

        self.g = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                         kernel_size=1, stride=1, padding=0)

        if bn_layer:
            self.W = nn.Sequential(
                conv_nd(in_channels=self.inter_channels, out_channels=self.in_channels,
                        kernel_size=1, stride=1, padding=0),
                bn(self.in_channels)
            )
            nn.init.constant_(self.W[1].weight, 0)
            nn.init.constant_(self.W[1].bias, 0)
        else:
            self.W = conv_nd(in_channels=self.inter_channels, out_channels=self.in_channels,
                             kernel_size=1, stride=1, padding=0)
            nn.init.constant_(self.W.weight, 0)
            nn.init.constant_(self.W.bias, 0)

        self.theta = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                             kernel_size=1, stride=1, padding=0)

        self.phi = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                           kernel_size=1, stride=1, padding=0)

        if sub_sample:
            self.g = nn.Sequential(self.g, max_pool_layer)
            self.phi = nn.Sequential(self.phi, max_pool_layer)

    def forward(self, x):
        '''
        :param x: (b, c, t, h, w)
        :return:
        '''

        batch_size = x.size(0)

        g_x = self.g(x).view(batch_size, self.inter_channels, -1)
        g_x = g_x.permute(0, 2, 1)

        theta_x = self.theta(x).view(batch_size, self.inter_channels, -1)
        theta_x = theta_x.permute(0, 2, 1)
        phi_x = self.phi(x).view(batch_size, self.inter_channels, -1)
        f = torch.matmul(theta_x, phi_x)
        N = f.size(-1)
        f_div_C = f / N

        y = torch.matmul(f_div_C, g_x)
        y = y.permute(0, 2, 1).contiguous()
        y = y.view(batch_size, self.inter_channels, *x.size()[2:])
        W_y = self.W(y)
        z = W_y + x

        return z


class NONLocalBlock1D(_NonLocalBlockND):
    def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
        super(NONLocalBlock1D, self).__init__(in_channels,
                                              inter_channels=inter_channels,
                                              dimension=1, sub_sample=sub_sample,
                                              bn_layer=bn_layer)


class NONLocalBlock2D(_NonLocalBlockND):
    def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
        super(NONLocalBlock2D, self).__init__(in_channels,
                                              inter_channels=inter_channels,
                                              dimension=2, sub_sample=sub_sample,
                                              bn_layer=bn_layer)


class NONLocalBlock3D(_NonLocalBlockND):
    def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
        super(NONLocalBlock3D, self).__init__(in_channels,
                                              inter_channels=inter_channels,
                                              dimension=3, sub_sample=sub_sample,
                                              bn_layer=bn_layer)


if __name__ == '__main__':
    import torch

    for (sub_sample, bn_layer) in [(True, True), (False, False), (True, False), (False, True)]:
        img = torch.zeros(2, 3, 20)
        net = NONLocalBlock1D(3, sub_sample=sub_sample, bn_layer=bn_layer)
        out = net(img)
        print(out.size())

        img = torch.zeros(2, 3, 20, 20)
        net = NONLocalBlock2D(3, sub_sample=sub_sample, bn_layer=bn_layer)
        out = net(img)
        print(out.size())

        img = torch.randn(2, 3, 8, 20, 20)
        net = NONLocalBlock3D(3, sub_sample=sub_sample, bn_layer=bn_layer)
        out = net(img)
        print(out.size())




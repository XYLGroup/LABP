import os
import time
import torch
import math
import cv2
import numpy as np
from PIL import Image
import scipy.io as sio
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.signal import convolve2d
from torch.nn import functional as F
from scipy.ndimage import measurements, interpolation
from scipy.interpolate import interp2d
import scipy.io as scio
import matplotlib.colors as mcolors
'''
# ------------------------------------------------
# util.py for ISAR SR, etc.
# ------------------------------------------------
'''

# 仿真数据读取函数
# data_list表示数据集路径list
# 仅读取hrrp文件，label通过ifft实现
# flag=1表示读取电磁仿真数据，需要将读取的hrrp先进行转置
# flag=0表示读取MATLAB仿真数据，hrrp无需转置
def readBatch_sim(mask, data_list, M, N, batch_size, total_size, data_ind, flag, OPM_output_dir):
    data_batch = np.zeros([batch_size, 1, M, N], dtype='complex64')
    label_batch = np.zeros([batch_size, 1, M, N], dtype='complex64')
    OMP_batch = np.zeros([batch_size, 1, M, N], dtype='complex64')
    for ind in range(batch_size):
        # list_number = ind_s * batch_size + ind
        file_name = data_list[data_ind % total_size]

        OMP_file_path = OPM_output_dir + 'num_{}_ISAR_SR.mat'.format(data_ind + 1)

        OMP_file = scio.loadmat(OMP_file_path)
        OMP_SR = OMP_file['hrrp']
        isar_echo = scio.loadmat(file_name)
        # print(data_list[data_ind % total_size])
        hrrp = isar_echo['hrrp']
        # hrrp = isar_echo['cv_img']

        img = np.fft.fft(hrrp, axis=-1)
        img = img/img.max()
        hrrp = np.fft.ifft(img, axis=-1)
        # plot_mat(np.abs(hrrp), OPM_output_dir + "/" + "hrrp.png", "ehco")
        # plot_mat(np.abs(hrrp1), OPM_output_dir + "/" + "hrrp1.png", "ehco")
        if flag:
            hrrp = hrrp.T
            hrrp = hrrp / np.max(np.abs(hrrp))
        else:
            hrrp = hrrp / np.max(np.abs(hrrp))
        hrrp_pad = np.multiply(mask, hrrp)
        # plot_mat(np.abs(hrrp_pad), output_dir + "/" + "masked_ehco.png", "masked_ehco")
        data_batch[ind, 0, :, :] = hrrp_pad
        label = np.fft.fft(hrrp, axis=-1)
        # plot_mat(np.abs(label), output_dir + "/" + "RDimage_with_full_aperture.png", "RDimage_with_full_aperture")
        label_batch[ind, 0, :, :] = label
        OMP_batch[ind, 0, :, :] = OMP_SR
        data_ind = data_ind+1

    # 返回tensor类型
    data_batch = torch.from_numpy(data_batch)
    label_batch = torch.from_numpy(label_batch)
    OMP_batch = torch.from_numpy(OMP_batch)

    return data_batch, label_batch, data_ind, OMP_batch


def get_mask(M, N, Sparse_rate, output_dir, mask_name):

    mask_path = os.path.join(output_dir, mask_name)

    if os.path.exists(mask_path):
        print(f'{mask_path} already exists! Read the mask!')
        mask = sio.loadmat(mask_path)['mask']
    else:
        ind = torch.randperm(M)
        Nsparse_row = torch.round(torch.tensor(Sparse_rate*M))
        # indind = torch.zeros(int(Nsparse_row))
        indind = ind[0:int(Nsparse_row)]
        mask = torch.zeros(M,M)
        mask[indind,:] = 1
        mask = mask.T
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        sio.savemat(mask_path, {'mask': mask.numpy()})
        plot_mat(mask, os.path.join(output_dir, "mask.png") , "mask")

    return mask

# def plot_mat(mat, path, filename):
#     plt.clf()
#     f, ax = plt.subplots(1, 1, figsize=(6, 4), squeeze=False)
#     im = ax[0, 0].imshow(mat, vmin=0, vmax=mat.max())
#     plt.colorbar(im, ax=ax[0, 0])
#     # im = ax[0, 1].imshow(out_k_np, vmin=0, vmax=out_k_np.max())
#     # plt.colorbar(im, ax=ax[0, 1])
#     ax[0, 0].set_title(filename)
#     # ax[0, 1].set_title('PSNR: {:.2f}'.format(calculate_psnr(gt_k_np, out_k_np, True)))
#
#     plt.savefig(path)

def plot_mat(mat, path, filename):
    plt.clf()
    f, ax = plt.subplots(1, 1, figsize=(6, 4), squeeze=False)

    im = ax[0, 0].imshow((mat), vmin=0, vmax=(mat).max(), cmap=plt.cm.get_cmap("viridis"))  # mcolors.LinearSegmentedColormap.from_list('mycmap', [ (0, 'darkblue'), (1,'yellow')])
    plt.colorbar(im, ax=ax[0, 0])
    # im = ax[0, 1].imshow(out_k_np, vmin=0, vmax=out_k_np.max())
    # plt.colorbar(im, ax=ax[0, 1])
    ax[0, 0].set_title(filename)
    # ax[0, 1].set_title('PSNR: {:.2f}'.format(calculate_psnr(gt_k_np, out_k_np, True)))

    plt.savefig(path)

def save_imagesc_mat2png(mat, path, filename):
    os.makedirs(os.path.join(path), exist_ok=True)
    mat = mat
    sio.savemat(path + filename + ".mat", {'hrrp': mat})
    plot_mat(mat, path + filename + ".png", filename)


def calculate_psnr(img1, img2, is_kernel=False):
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)

    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(1.0 / math.sqrt(mse)) if is_kernel else 20 * math.log10(255.0 / math.sqrt(mse))


def ssim(img1, img2):
    C1 = (0.01 * 255) ** 2
    C2 = (0.03 * 255) ** 2

    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)
    kernel = cv2.getGaussianKernel(11, 1.5)
    window = np.outer(kernel, kernel.transpose())

    mu1 = cv2.filter2D(img1, -1, window)[5:-5, 5:-5]  # valid
    mu2 = cv2.filter2D(img2, -1, window)[5:-5, 5:-5]
    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2
    sigma1_sq = cv2.filter2D(img1 ** 2, -1, window)[5:-5, 5:-5] - mu1_sq
    sigma2_sq = cv2.filter2D(img2 ** 2, -1, window)[5:-5, 5:-5] - mu2_sq
    sigma12 = cv2.filter2D(img1 * img2, -1, window)[5:-5, 5:-5] - mu1_mu2

    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) *
                                                            (sigma1_sq + sigma2_sq + C2))
    return ssim_map.mean()


def calculate_ssim(img1, img2):
    '''calculate SSIM
    the same outputs as MATLAB's
    img1, img2: [0, 255]
    '''
    if not img1.shape == img2.shape:
        raise ValueError('Input images must have the same dimensions.')
    if img1.ndim == 2:
        return ssim(img1, img2)
    elif img1.ndim == 3:
        if img1.shape[2] == 3:
            ssims = []
            for i in range(3):
                ssims.append(ssim(img1[:, :, i], img2[:, :, i]))
            return np.array(ssims).mean()
        elif img1.shape[2] == 1:
            return ssim(np.squeeze(img1), np.squeeze(img2))
    else:
        raise ValueError('Wrong input image dimensions.')

def rgb2ycbcr(img, only_y=True):
    '''same as matlab rgb2ycbcr
    only_y: only return Y channel
    Input:
        uint8, [0, 255]
        float, [0, 1]
    '''
    in_img_type = img.dtype
    img.astype(np.float32)
    if in_img_type != np.uint8:
        img *= 255.
    # convert
    if only_y:
        rlt = np.dot(img, [65.481, 128.553, 24.966]) / 255.0 + 16.0
    else:
        rlt = np.matmul(img, [[65.481, -37.797, 112.0], [128.553, -74.203, -93.786],
                              [24.966, 112.0, -18.214]]) / 255.0 + [16, 128, 128]
    if in_img_type == np.uint8:
        rlt = rlt.round()
    else:
        rlt /= 255.
    return rlt.astype(in_img_type)

def read_mat(path):
    """Loads an image"""

    isar_echo = scio.loadmat(path)
    hrrp = isar_echo['hrrp']

    return hrrp

def evaluation_dataset(input_dir, output_dir):
    ''' Evaluate the model with kernel and image PSNR'''
    print('Calculating PSNR...')


    filesource = os.listdir(os.path.abspath(output_dir))  # + sub_set

    filesource.sort()
    output_dir_abs = os.path.abspath(output_dir)
    txtname = output_dir_abs + "\\PSNR_and_SSIM.txt"
    myfile = open(txtname, 'w')

    im_psnr = 0
    im_ssim = 0
    kernel_psnr = 0
    for filename in filesource:

        if filename[-3:] == "mat":

            # load SR
            path = os.path.join(output_dir, filename)
            sr = read_mat(path)

            # load HR
            path = os.path.join(input_dir, filename)
            hr = read_mat(path)



        # # calculate psnr
        # hr = rgb2ycbcr(hr / 255., only_y=True)
        # sr = rgb2ycbcr(sr / 255., only_y=True)
        #
        # if sr.shape[0]>hr.shape[0] or sr.shape[1]>hr.shape[1]:
        #
        #     a = sr.shape[0] - hr.shape[0]
        #     b = sr.shape[1] - hr.shape[1]
        #     sr = sr[a // 2 : sr.shape[0] - (a - a // 2), b // 2 : sr.shape[1] - (b - b // 2)]
        #
        # if hr.shape[0] > sr.shape[0] or hr.shape[1] > sr.shape[1]:
        #     a = hr.shape[0] - sr.shape[0]
        #     b = hr.shape[1] - sr.shape[1]
        #     hr = hr[a // 2: hr.shape[0] - (a - a // 2), b // 2: hr.shape[1] - (b - b // 2)]
        #
        # if conf.IF_DIV2K == True:
        #     hr = hr[hr.shape[0] // 2 - conf.crop * 2: hr.shape[0] // 2 + conf.crop * 2,
        #                hr.shape[1] // 2 - conf.crop * 2: hr.shape[1] // 2 + conf.crop * 2]
        #
        # crop_border = conf.sf
        #
        #
        #
        # cropped_hr = hr[crop_border:-crop_border, crop_border:-crop_border]
        # cropped_sr = sr[crop_border:-crop_border, crop_border:-crop_border]
        # im_psnr += calculate_psnr(cropped_hr * 255, cropped_sr * 255)
        # im_ssim += calculate_ssim(cropped_hr * 255, cropped_sr * 255)
        # myfile.write("image_num:{%s}\tPSNR:{%.2f}\tSSIM:{%.4f}\tPSNR_KERNEL:{%.2f}\n" % (filename, calculate_psnr(cropped_hr * 255, cropped_sr * 255), calculate_ssim(cropped_hr * 255, cropped_sr * 255),kernel_psnr))
        #

        # psnr, ssim = comp_upto_shift(hr * 255, sr*255, maxshift=1, border=conf.sf, min_interval=0.25)
        # im_psnr += psnr
        # im_ssim += ssim

        # ADMM imaging
        # 参数定义
        # paras = [0.1, 0.1, 0.01, 0.1]
        #
        # ADMM_image = ADMM_forward(100, paras, mask_torch, hrrp_batch.squeeze(0))
        #
        # if not os.path.exists(ADMM_output_dir):
        #     os.makedirs(ADMM_output_dir)
        #
        # save_imagesc_mat2png(abs(ADMM_image.cpu()).squeeze(0), ADMM_output_dir, "num_{}_ISAR_ADMM".format(data_ind))
        #
        # RDimage_ADMM_image = torch.fft.ifftshift((torch.fft.fft(ADMM_image.cpu().squeeze(0), N, 1)), 1)
        # save_imagesc_mat2png(abs(RDimage_ADMM_image), ADMM_output_dir, "num_{}_ISAR_ADMM_RD".format(data_ind))
        #
        # a = 1

    print('{}_iter{} ({} images), Average Imgae PSNR/SSIM: {:.2f}/{:.4f}, Average Kernel PSNR: {:.2f}####################################################################################'.format(conf.output_dir_path,
                                                                                                  used_iter,len(filesource),im_psnr / len(filesource),im_ssim / len(filesource),kernel_psnr / len(filesource)))

    myfile.write("*****Average Result: image_num:{%.0f}\tPSNR:{%.2f}\tSSIM:{%.4f}\tkernelPSNR:{%.4f}*****" % (len(filesource), (im_psnr / len(filesource)), (im_ssim / len(filesource)), (kernel_psnr / len(filesource))))
    myfile.close()

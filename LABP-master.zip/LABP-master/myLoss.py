import torch
from torch import nn


class myMSELoss(nn.Module):
    def __init__(self):
        super(myMSELoss, self).__init__()
        return

    def forward(self, data, label, batch_size):
        mat = (data - label).abs()
        l = torch.sum( mat*mat )
        l = l/batch_size
        return l


class RMSELoss(nn.Module):
    def __init__(self):
        super(RMSELoss, self).__init__()
        return

    def forward(self, data, label, batch_size):
        mat = (data - label).abs()
        mat_2_sum = torch.sum(mat*mat)
        MSE = mat_2_sum/(data.shape[0]*data.shape[1]*data.shape[2]*data.shape[3])

        RMSE = torch.sqrt(MSE)

        return RMSE

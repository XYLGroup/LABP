import torch

from utils_9_6 import *

import tqdm

from data.dataset import *
from util import *
import os
from myLoss import myMSELoss, RMSELoss
from model import *


device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
method = "ISAR_imaging"


# 参数定义
nums = 1  #  50  5
M = 193
N = M
T_flag = 0
n_stage = 20
batch_size = 1
data_ind = 0
mu = 0.01
rho_init = 0.1
lam_init = 0.1

Sparse_rate = 0.25  # 0.25, 0.125

SNR = 1000  #  1000 for no noise
noise_AC = 1


Z_0 = torch.zeros(batch_size, 1, M, N).to(device)
# A_0 = torch.zeros(batch_size, 1, M, N).to(device)
lowest_loss = 1000

D_dip_lr = 5e-5   #  1e-3  1e-4
input_lr = 1e-4
AM_num = 1

mate_num_T = 4   # 1 - 10
max_iters = 80

dip_lr =  mate_num_T * 6e-4 - 4e-4



# max_iters = mate_num_T * max_num_K
OMP_first_num = 1
OMP_num = 1  #  3
print_step = 4  #  50

if __name__ == '__main__':
    # 创建dataset.txt数据集，将flower_photos修改为自己的数据集名称

    model = 'CV-DIP'

    dataset_path_root = '../{}/data/datasets/'.format(model)

    dataset = "ISAR satellite" # ISAR satellite, data_simple, 101_sparse

    dataset_path = os.path.join(dataset_path_root, dataset)
    data_dir = '../{}/data/log_HR/{}_lr_x{}/'.format(model, dataset, Sparse_rate)

    RD_output_dir = '../{}/data/log_RD/{}_lr_x{}/Test/'.format(model, dataset, Sparse_rate)

    CV_DIP_dir = '../{}/data/log_CV-DIP/{}_lr_x{}/Test/'.format(model, dataset, Sparse_rate)

    CV_DIP_withoutDIP_dir = '../{}/data/log_CV-DIPwithoutDIP/{}_lr_x{}/Test/'.format(model, dataset, Sparse_rate)

    OPM_output_dir = '../{}/data/log_OMP/{}_lr_x{}/Test/10/'.format(model, dataset, Sparse_rate)

    # ADMM_output_dir = '../{}/data/log_ADMM/{}_lr_x{}/'.format(model, dataset, Sparse_rate)


    if not os.path.exists(data_dir):
        os.makedirs(data_dir)

    if not os.path.exists(CV_DIP_withoutDIP_dir):
        os.makedirs(CV_DIP_withoutDIP_dir)

    text_name = "path.txt"
    train_name = "train.txt"
    val_name = "val.txt"
    test_name = "test.txt"

    dataset_txt_path = os.path.join(data_dir, text_name)
    dataset_train_path = os.path.join(data_dir, train_name)
    dataset_val_path = os.path.join(data_dir, val_name)
    dataset_test_path = os.path.join(data_dir, test_name)

    write_dataset2txt(dataset_path, dataset_txt_path)


    mask_name = "mask.mat"
    # mask_path = os.path.join(output_dir, mask_name)

    mask = get_mask(M, N, Sparse_rate, data_dir, mask_name)
    mask_torch = torch.tensor(mask).clone().detach().to(device)

    # 划分训练集、验证集与测试集
    img_list = get_image_path(dataset_txt_path)  # 读取dataset.txt中的内容获得图片路径
    train_rate = 0.6  # 训练集比重60%
    val_rate = 0.2  # 验证集比重20%，测试集比重20%

    write_train_val_test_list(img_list, train_rate, val_rate, dataset_train_path, dataset_val_path, dataset_test_path)

    # 获取训练集和验证集图片路径与标签
    # train_img_path, train_labels, val_img_path, val_labels, classes = get_train_and_val(dataset_train_path, dataset_val_path)

    train_img_list = get_dataset_list(dataset_train_path)
    val_img_list = get_dataset_list(dataset_val_path)
    test_img_list = get_dataset_list(dataset_test_path)

    print(f'Total of training images: {len(train_img_list)}')
    print(f'Total of val images: {len(val_img_list)}')
    print(f'Total of testing images: {len(test_img_list)}')


    input_dip = get_noise(1, 'noise', (M, N)).to(device).detach().type(torch.complex64)
    # self.input_dip = get_noise(C, 'noise', (125, 125)).to(device).detach()

    input_dip.requires_grad = False

    net_cv_dip = ComplexUnet(1, 1).to(device)
    opt = torch.optim.Adam(net_cv_dip.parameters(), lr=mu)
    optimizer_dip = torch.optim.Adam([{'params': net_cv_dip.parameters()}], lr=dip_lr)
    loss_fn = myMSELoss()
    loss_RMSE = RMSELoss()
    mse = torch.nn.MSELoss().to(device)


    # 定义了ADMM前向传播过程
    def ADMM_forward(iter, para_list, mask, Y):
        # para_list: 4*iter-3 维的tensor，分别是rho_x, rho_z, lam_z, rho_a
        # M: 全孔径数据方位维
        # N: 全孔径数据距离维
        # mask: MxN维矩阵
        # X, Y, A, Z: batch x M x N维矩阵

        batch_size = Y.size(0)
        M = Y.size(1)
        N = Y.size(2)

        Z = torch.ones(batch_size, M, N).to(device)
        A = torch.ones(batch_size, M, N).to(device)

        for ii in range(iter - 1):
            TmpMtx = (Y + 1 / c.sqrt(M) * torch.fft.fft(para_list[0] * Z - A, M, 1)) / (mask + para_list[0] * torch.ones(M, N).to(device))

            X = c.sqrt(M) * torch.fft.ifft(TmpMtx, M, 1)

            Z = mySoftThreshod(X + A / para_list[1], para_list[2] / para_list[1])

            A = A + para_list[3] * (X - Z)

        TmpMtx = (Y + 1 / c.sqrt(M) * torch.fft.fft(para_list[0] * Z - A, M, 1)) / (
                mask + para_list[0] * torch.ones(M, N).to(device))
        X = c.sqrt(M) * torch.fft.ifft(TmpMtx, M, 1)

        return X


    ave_RMSE = 0

    for ind_s in range(nums):

        # ind_s = ind_s + 17
        # 读取支撑集里的一个batch

        wb = xlwt.Workbook()  # 一个实例
        sheet = wb.add_sheet("Sheet1")  # 工作簿名称
        style = "font:colour_index black;"  # 设置样式
        black_style = xlwt.easyxf(style)
        sheet.write(0, 1, "RMSE loss")
        sheet.write(0, 2, "RE loss")
        sheet.write(0, 3, "D loss")

        for i in range(1, max_iters):
            sheet.write(i, 0, str(i))  # 不设置格式
            wb.save(CV_DIP_dir + "/" + "num_{}_SR.xls".format(data_ind + 1))  # 最后一定要保存，否则无效



        col1 = 1
        col2 = 2
        col3 = 3

        data_batch, label_batch, data_ind, OMP_batch = readBatch_sim(mask, test_img_list,
                                                          M, N, batch_size, len(test_img_list), (ind_s), T_flag,
                                                          OPM_output_dir)  #  OPM_output_dir, data_dir

        OMP_batch = outputNormalization4D(OMP_batch)

        M = data_batch.shape[2]
        N = data_batch.shape[3]



        if SNR == 1000:
            noise = 0
        else:
            P_signal = 0
            for ii in range(M):
                for jj in range(N):
                    P_signal = P_signal + data_batch[:, :, ii, jj] ** 2
            P_signal = P_signal / ((M+1) * (N+1))
            P_noise = P_signal / (10 ** (SNR / 10)) * noise_AC
            noise = P_noise * np.random.normal(0, 1, size=(1,1,M,N))
            noise_j = P_noise * np.random.normal(0, 1, size=(1,1,M,N))
            noise = noise + 1j * noise_j
            noise = noise.to(device)


        hrrp_batch = data_batch.to(device)
        ISAR_image_batch = label_batch.to(device)
        OMP_batch = OMP_batch.to(device)

        save_imagesc_mat2png((abs(hrrp_batch.cpu().squeeze(0).squeeze(0).numpy())), data_dir, "num_{}_hrrp".format(data_ind))

        OMP_batch.requires_grad = True

        LABP_without_G_input = OMP_batch
        LABP_without_G_input.requires_grad = True

        # hrrp_iffted = torch.fft.ifft(ISAR_image_hr, dim=-1)
        # save_imagesc_mat2png(abs(hrrp_iffted), data_dir, "num_{}_hrrp_shiftd".format(data_ind))

        # # RD imaging
        # RDimage_unfull = torch.fft.ifftshift((torch.fft.fft(hrrp_batch.cpu().squeeze(0).squeeze(0), N, 1)), 1)
        # RD_image = abs(RDimage_unfull)
        # RD_image = RD_image.cpu().numpy()
        # save_imagesc_mat2png(RD_image, RD_output_dir, "num_{}_ISAR_SR".format(data_ind))

        HR_image_tc = abs(torch.fft.fftshift(ISAR_image_batch.cpu().squeeze(0).squeeze(0), 1))
        HR_image = HR_image_tc.cpu().numpy()
        save_imagesc_mat2png(HR_image, RD_output_dir,
                             "num_{}_ISAR_HR".format(data_ind))

        HR_image_tc = HR_image_tc.unsqueeze(0).unsqueeze(0)
        HR_image_tc = outputNormalization4D(HR_image_tc).to(device)


        # # CV-DIP imaging ##########################################################################################

        net_cv_dip = ComplexUnet(1, 1).to(device)
        opt = torch.optim.Adam(net_cv_dip.parameters(), lr=mu)
        optimizer_dip = torch.optim.Adam([{'params': net_cv_dip.parameters()}], lr=dip_lr)
        D_optimizer_dip = torch.optim.Adam([{'params': net_cv_dip.parameters()}], lr=D_dip_lr)
        optimizer_input = torch.optim.Adam([{'params': OMP_batch}], lr=input_lr)

        strat_time = time.time()

        input = OMP_batch

        # input =

        for i in range(OMP_first_num):
            out_ISAR_SR = net_cv_dip(input)  # input_dip
            out_ISAR_SR = outputNormalization4D(out_ISAR_SR)  # 向量化归一化

            loss_D = loss_fn(out_ISAR_SR, OMP_batch, batch_size)
            loss_D.backward(retain_graph=True)
            loss_D.detach()
            D_optimizer_dip.step()
            D_optimizer_dip.zero_grad()


        for iteration in tqdm.tqdm(range(max_iters), ncols=60):
        # for iteration in range(max_iters):

            # LABP_without_G_input = outputNormalization4D(LABP_without_G_input.detach().clone())
            # LABP_without_G = LABP_without_G_input.detach().clone()
            # LABP_without_G.requires_grad = True
            # optimizer_LABP_without_G = torch.optim.Adam(LABP_without_G.imag, lr=input_lr)
            # optimizer_LABP_without_G.zero_grad()
            # for jj in range(100):
            #     print(jj)
            #
            #     # LABP_without_G = torch.fft.fftshift(LABP_without_G, 3)
            #     # LABP_without_G_input_iffted = torch.fft.ifft(LABP_without_G, dim=-1)
            #     # LABP_without_G_input_iffted_masked = LABP_without_G_input_iffted * mask_torch.unsqueeze(0).unsqueeze(0)
            #
            #     loss_LABP = loss_RMSE(LABP_without_G, hrrp_batch, batch_size)
            #     loss_LABP.backward(retain_graph=True)
            #
            #     optimizer_LABP_without_G.step()
            #     optimizer_LABP_without_G.zero_grad()
            #
            #     LABP_without_G = LABP_without_G.detach().clone()
            #
            #     if (jj + 1) % print_step == 0:
            #
            #         LABP_without_G_input = outputNormalization4D(LABP_without_G_input)  # 向量化归一化
            #         Loss_LABP = loss_RMSE(LABP_without_G_input, HR_image_tc, batch_size)
            #
            #         print('\n Num {}, Iter {}, loss_RMSE: {}'.format(ind_s, (iteration + 1), Loss_LABP))
            #         LABP_without_G_image = LABP_without_G_input.cpu().detach().squeeze(0).squeeze(0)
            #
            #         save_imagesc_mat2png(abs(LABP_without_G_image), CV_DIP_withoutDIP_dir,
            #                              "num_{}_iters_{}_out_ISAR_image".format(data_ind, (iteration + 1)))
            #
            #         sheet.write((iteration) + 1, col1, '%.4f' % Loss_RMSE, black_style)
            #         wb.save(CV_DIP_withoutDIP_dir + "/" + "num_{}_SR.xls".format(data_ind))  # 最后一定要保存，否则无效



            if model == 'CV-DIP':

                loss_RE = 0
                loss_meta = 0
                optimizer_dip.zero_grad()
                # OMP_batch.requires_grad = True

                for i in range(AM_num):

                    optimizer_input.zero_grad()

                    out_ISAR_SR = net_cv_dip(input)   # input_dip

                    out_ISAR_SR = outputNormalization4D(out_ISAR_SR)  # 向量化归一化

                    out_ISAR_SR = torch.fft.fftshift(out_ISAR_SR, 3)

                    out_hrrp_iffted = torch.fft.ifft(out_ISAR_SR, dim=-1)

                    out_hrrp_iffted_masked = out_hrrp_iffted * mask_torch.unsqueeze(0).unsqueeze(0)

                    out_hrrp_iffted_masked = outputNormalization4D(out_hrrp_iffted_masked)
                    hrrp_batch = outputNormalization4D(hrrp_batch + noise)

                    loss_RE = loss_RMSE(out_hrrp_iffted_masked, hrrp_batch, batch_size)
                    loss_RE.backward(retain_graph=True)
                    loss_RE.detach()


                    optimizer_input.step()
                    optimizer_input.zero_grad()

                    out_mate = net_cv_dip(input.clone().detach())
                    out_mate = outputNormalization4D(out_mate)
                    out_mate = torch.fft.fftshift(out_mate, 3)
                    out_mate_iffted = torch.fft.ifft(out_mate, dim=-1)
                    out_mate_iffted_masked = out_mate_iffted * mask_torch.unsqueeze(0).unsqueeze(0)

                    loss_meta = loss_meta + loss_fn(out_mate_iffted_masked, hrrp_batch, batch_size)

                    if (iteration + 1) % mate_num_T == 0:
                        # OMP_batch.requires_grad = False

                        loss_meta.backward(retain_graph=True)
                        loss_meta.detach()

                        optimizer_dip.step()
                        optimizer_dip.zero_grad()

                        loss_meta = 0


                input.requires_grad = False
                loss_D = 0
                optimizer_dip.zero_grad()

                for i in range(OMP_num):
                    out_ISAR_SR = net_cv_dip(input)  # input_dip
                    out_ISAR_SR = outputNormalization4D(out_ISAR_SR + noise)  # 向量化归一化

                    loss_D = loss_RMSE(out_ISAR_SR, OMP_batch, batch_size)
                    loss_D.backward(retain_graph=True)
                    loss_D.detach()
                    D_optimizer_dip.step()
                    D_optimizer_dip.zero_grad()


                # # 打印相关信息
                if (iteration + 1) % print_step == 0:
                    out_ISAR_SR = net_cv_dip(OMP_batch)  # input_dip
                    out_ISAR_SR = outputNormalization4D(out_ISAR_SR)  # 向量化归一化
                    Loss_RMSE = loss_RMSE(out_ISAR_SR, HR_image_tc, batch_size)

                    print('\n Num {}, Iter {}, loss_RMSE: {}, loss_RE: {}, loss_D: {}'.format(ind_s, (iteration + 1), Loss_RMSE, loss_RE.data, loss_D.data))
                    out_ISAR_image = out_ISAR_SR.cpu().detach().squeeze(0).squeeze(0)
                    save_imagesc_mat2png(abs(out_ISAR_image), CV_DIP_dir, "num_{}_iters_{}_out_ISAR_image".format(data_ind, (iteration + 1)))

                    sheet.write((iteration) + 1, col1, '%.4f' % Loss_RMSE, black_style)
                    wb.save(CV_DIP_dir + "/" + "num_{}_SR.xls".format(data_ind))  # 最后一定要保存，否则无效
                    sheet.write((iteration) + 1, col2, '%.4f' % loss_RE.data, black_style)
                    wb.save(CV_DIP_dir + "/" + "num_{}_SR.xls".format(data_ind))  # 最后一定要保存，否则无效
                    sheet.write((iteration) + 1, col3, '%.4f' % loss_D.data, black_style)
                    wb.save(CV_DIP_dir + "/" + "num_{}_SR.xls".format(data_ind + 1))  # 最后一定要保存，否则无效

        Runtime = time.time() - strat_time

        ISAR_image_hr = ISAR_image_batch.cpu().squeeze(0).squeeze(0)
        HR = abs(torch.fft.fftshift(ISAR_image_hr, 1))
        HR = outputNormalization2D(HR)
        HR = HR.cpu().numpy()
        save_imagesc_mat2png(HR, CV_DIP_dir,
                             "num_{}_ISAR_HR".format(data_ind))

        out_ISAR_image = out_ISAR_SR.cpu().detach().squeeze(0).squeeze(0)
        # SR = abs(torch.fft.fftshift(out_ISAR_image, 1))
        SR = abs(out_ISAR_image)
        SR = outputNormalization2D(SR)
        SR = SR.cpu().numpy()
        save_imagesc_mat2png(SR, CV_DIP_dir,
                             "num_{}_ISAR_SR".format(data_ind))

        out_ISAR_SR = net_cv_dip(OMP_batch)  # input_dip
        out_ISAR_SR = outputNormalization4D(out_ISAR_SR)  # 向量化归一化
        Loss_RMSE = loss_RMSE(out_ISAR_SR, HR_image_tc, batch_size)

        ave_RMSE = ave_RMSE + Loss_RMSE


        # OMP_SR = OMP_batch.cpu().detach().squeeze(0).squeeze(0)
        #
        # OMP_SR = outputNormalization2D(OMP_SR)
        # OMP_SR = abs(OMP_SR.cpu().numpy())
        # save_imagesc_mat2png(OMP_SR, CV_DIP_dir,
        #                      "num_{}_ISAR_OMP".format(data_ind))


    ave_RMSE = ave_RMSE/nums

    print("nums: {}, average RMSE: {}".format(nums, ave_RMSE))

#
# new(fc, Bw, Tp, fs, PRF, SNR, omiga, M, Nscat, SRrate)


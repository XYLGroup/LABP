import torch
import numpy as np
import scipy.io as scio
import matplotlib.pyplot as plt
import sys
import math

# -*- coding: utf-8 -*-

def myReadTxt(path):
    '''
    读取txt文件，并将每一行读出来，存在列表里
    '''
    fo = open(path, "r", encoding= 'utf-8')
    result = []

    for line in fo.readlines():  # 依次读取每行
        line = line.strip()  # 去掉每行头尾空白
        result.append(line)

    # 关闭文件
    fo.close()

    return result


def outputNormalization4D(im):
    '''
    把网络输出im向量化，然后归一化
    :param im: batch x C x M x N
    :return: im_norm: batch x C x M x N
    '''
    batch_size = im.size(0)
    # M = im.size(-2)
    # N = im.size(-1)

    # im_norm = torch.zeros(batch_size, 1, M, N, dtype=torch.complex128)
    #
    im_abs = im.clone().detach().abs()
    for ii in range(batch_size):
        max_v = im_abs[ii,:,:,:].max()
        im[ii,0,:,:] = im[ii,0,:,:] / max_v

    return im


def outputNormalization2D(im):
    '''
    把网络输出im向量化，然后归一化
    :param im: M x N
    :return: im_norm: M x N
    '''


    im_abs = im.clone().detach().abs()
    max_v = im_abs[:,:].max()
    im[:,:] = im[:,:] / max_v

    return im


def myRepMask(batch_size, mask):
    '''
    :param batch_size:
    :param mask: numpy 类型
    :return: Tensor类型的mask_rep
    '''
    m = mask.shape[0]
    n = mask.shape[1]
    mask_rep = np.zeros([batch_size,m,n])
    for ii in range(batch_size):
        mask_rep[ii,:,:] = mask
    mask_rep = torch.from_numpy(mask_rep)
    return mask_rep



def mySoftThreshod(X, thresh):
    '''
    :param X: batch_size x M x N
    :param thresh: real scalar
    :return: re: batch_size x M x N
    '''
    re = X/torch.abs(X) * torch.max( torch.abs(X) - thresh, torch.zeros(X.shape).cuda() )
    return re


def myComplexExp(theta_tensor):
    re = torch.complex(torch.cos(theta_tensor), torch.sin(theta_tensor))
    re = re.type(torch.complex64)
    return re


def myCalAngle(num):
    # 输入为一个复数(tensor)
    i = torch.imag(num)
    r = torch.real(num)
    if i>=0 and r>=0:
        return torch.arctan(i / (r+1e-8))
    elif i>=0 and r<0:
        return torch.arctan(i / (r+1e-8)) + math.pi
    elif i<0 and r>=0:
        return torch.arctan(i / (r+1e-8))
    else:
        return torch.arctan(i / (r + 1e-8)) - math.pi


def initFai(mask, fai_list, data_ind, batch_size, L, total_size):
    fai = np.zeros([batch_size, L, 1])
    sparse_ind = np.nonzero(mask[:,0])
    sparse_ind = sparse_ind[0] # 从turple里把array取出来
    for ii in range(batch_size):
        fai_single = scio.loadmat(fai_list[data_ind % total_size]) # load进来的是Mx1的矩阵
        fai_single = fai_single['fai']
        fai[ii] = fai_single[sparse_ind, :]
        data_ind = data_ind + 1
    fai = torch.from_numpy(fai)
    return fai, data_ind


# 仿真数据读取函数
# data_list表示数据集路径list
# 仅读取hrrp文件，label通过ifft实现
# flag=1表示读取电磁仿真数据，需要将读取的hrrp先进行转置
# flag=0表示读取MATLAB仿真数据，hrrp无需转置
# def readBatch_sim(mask, data_list, M, N, batch_size, total_size, data_ind, flag):
#     data_batch = np.zeros([batch_size, M, N], dtype='complex64')
#     label_batch = np.zeros([batch_size, M, N], dtype='complex64')
#     for ind in range(batch_size):
#         isar_echo = scio.loadmat( data_list[data_ind % total_size] )
#         hrrp = isar_echo['hrrp']
#         if flag:
#             hrrp = hrrp.T
#             hrrp = hrrp / np.max(np.abs(hrrp))
#         else:
#             hrrp = hrrp / np.max(np.abs(hrrp))
#         hrrp_pad = mask*hrrp
#         data_batch[ind,:,:] = hrrp_pad
#
#         label = np.fft.ifft(hrrp,axis=0) # 判断ifft是否正确？
#
#         label_batch[ind, :, :] = label
#         data_ind = data_ind+1
#
#     # 返回tensor类型
#     data_batch = torch.from_numpy(data_batch)
#     label_batch = torch.from_numpy(label_batch)
#
#     return data_batch, label_batch, data_ind


# 实测数据读取函数
# 同时读取hrrp文件与label文件
def readBatch_mes(mask, data_list, data_label_list, M, N, batch_size, total_size, data_ind):
    data_batch = np.zeros([batch_size, M, N], dtype='complex64')
    label_batch = np.zeros([batch_size, M, N], dtype='complex64')
    for ind in range(batch_size):
        isar_echo = scio.loadmat( data_list[data_ind % total_size] )
        hrrp = isar_echo['isar_echo'] / np.max(np.abs(isar_echo['isar_echo']))
        # hrrp = isar_echo['hrrp']
        hrrp_pad = mask*hrrp
        data_batch[ind,:,:] = hrrp_pad

        img = scio.loadmat( data_label_list[data_ind % total_size] )
        label = img['cv_img2'] / np.max(np.abs(img['cv_img2']))
        # label = img['cv_img2']
        # label = img['RD']
        label_batch[ind, :, :] = label
        data_ind = data_ind+1

    # 返回tensor类型
    data_batch = torch.from_numpy(data_batch)
    label_batch = torch.from_numpy(label_batch)

    return data_batch, label_batch, data_ind


# 实测自聚焦数据读取函数，与mes唯一区别在于归一化权重
# 同时读取hrrp文件与label文件
def readBatch_mes_AF(mask, data_list, data_label_list, M, N, batch_size, total_size, data_ind):
    data_batch = np.zeros([batch_size, M, N], dtype='complex64')
    label_batch = np.zeros([batch_size, M, N], dtype='complex64')
    for ind in range(batch_size):
        isar_echo = scio.loadmat( data_list[data_ind % total_size] )
        hrrp = 100*isar_echo['isar_echo'] / np.max(np.abs(isar_echo['isar_echo']))
        # hrrp = isar_echo['hrrp']
        hrrp_pad = mask*hrrp
        data_batch[ind,:,:] = hrrp_pad

        img = scio.loadmat( data_label_list[data_ind % total_size] )
        label = img['cv_img2'] / np.max(np.abs(img['cv_img2']))
        # label = img['cv_img2']
        # label = img['RD']
        label_batch[ind, :, :] = label
        data_ind = data_ind+1

    # 返回tensor类型
    data_batch = torch.from_numpy(data_batch)
    label_batch = torch.from_numpy(label_batch)

    return data_batch, label_batch, data_ind
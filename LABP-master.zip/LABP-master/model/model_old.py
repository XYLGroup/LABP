import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import sys
import tqdm
import os
import cv2
import math
import matplotlib.pyplot as plt
from .networks import skip, fcn, tiny_skip
from .SSIM import SSIM
import scipy.io as sio
from torch import optim




sys.path.append('../')
from util import save_final_kernel_png, get_noise, kernel_shift, move2cpu, tensor2im01, kernel_move

sys.path.append('../../')

from torch.utils.tensorboard import SummaryWriter

'''
# ------------------------------------------
# models of MLMC, etc.
# ------------------------------------------
'''


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion * planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out

class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_planes, planes, stride=1):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, self.expansion * planes,
                               kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(self.expansion * planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion * planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = F.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out

class ResNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=10):
        super(ResNet, self).__init__()
        self.in_planes = 64

        self.conv1 = nn.Conv2d(3, 64, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)
        self.linear = nn.Linear(512 * block.expansion, num_classes)

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = F.avg_pool2d(out, 4)
        out = out.view(out.size(0), -1)
        out = self.linear(out)
        return out



class ISARDIP:
    '''
    # ------------------------------------------
    # (1) create model, loss and optimizer
    # ------------------------------------------
    '''

    def estimate_variance(self, padding_mode="reflect"):
        self.noise2 = (self.lr - self.blur_and_downsample.data)**2
        self.noise2_mean = self.noise2.mean()
        if self.conf.noise_estimator == 'niid':
            noise2_pad = F.pad(input=self.noise2, mode = padding_mode, pad = ((self.args.window_variance - 1) //2, )*4)
            self.lambda_p = F.conv2d(input = noise2_pad,
                                     weight = self.var_filter.expand(self.lr.shape[1], -1, -1, -1),
                                     groups= self.lr.shape[1])
        elif self.conf.noise_estimator == 'iid':
            self.lambda_p = torch.ones_like(self.lr) * self.noise2.mean()

        elif self.conf.noise_estimator == 'no-noise':
            self.lambda_p = torch.ones_like(self.lr)

        else:
            sys.exit('Please input corrected noise estimation methods: iid or niid!')

    def make_gradient_filter(self):
        filters = np.zeros([4, 3, 3], dtype=np.float32)
        filters[0,] = np.array([[0,  -1, 0],
                                [0,  1,  0],
                                [0,  0,  0]])

        filters[1,] = np.array([[-1, 0,  0],
                                [0,  1,  0],
                                [0,  0,  0]])

        filters[2,] = np.array([[0,  0, 0],
                                [-1, 1, 0],
                                [0,  0, 0]])

        filters[3,] = np.array([[0,  0, 0],
                                [0,  1, 0],
                                [-1, 0, 0]])

        self.grad_filters = torch.from_numpy(filters).cuda()

    def calculate_grad_abs(self, padding_mode="reflect"):
        hr_pad = F.pad(input = self.im_HR_est, mode = padding_mode, pad = (1, ) * 4)
        out = F.conv3d(input = hr_pad.expand(self.grad_filters.shape[0], -1, -1, -1).unsqueeze(0),
                       weight = self.grad_filters.unsqueeze(1).unsqueeze(1),
                       stride = 1, groups = self.grad_filters.shape[0])

        return torch.abs(out.squeeze(0))

    def calculate_parameters(self, net):
        out = 0
        for param in net.parameters():
            out += param.numel()
        return out

    def ssim(self, img1, img2):
        C1 = (0.01 * 255) ** 2
        C2 = (0.03 * 255) ** 2

        img1 = img1.astype(np.float64)
        img2 = img2.astype(np.float64)
        kernel = cv2.getGaussianKernel(11, 1.5)
        window = np.outer(kernel, kernel.transpose())

        mu1 = cv2.filter2D(img1, -1, window)[5:-5, 5:-5]  # valid
        mu2 = cv2.filter2D(img2, -1, window)[5:-5, 5:-5]
        mu1_sq = mu1 ** 2
        mu2_sq = mu2 ** 2
        mu1_mu2 = mu1 * mu2
        sigma1_sq = cv2.filter2D(img1 ** 2, -1, window)[5:-5, 5:-5] - mu1_sq
        sigma2_sq = cv2.filter2D(img2 ** 2, -1, window)[5:-5, 5:-5] - mu2_sq
        sigma12 = cv2.filter2D(img1 * img2, -1, window)[5:-5, 5:-5] - mu1_mu2

        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) *
                                                                (sigma1_sq + sigma2_sq + C2))
        return ssim_map.mean()

    def rgb2ycbcr(self, img, only_y=True):
        '''same as matlab rgb2ycbcr
        only_y: only return Y channel
        Input:
            uint8, [0, 255]
            float, [0, 1]
        '''
        in_img_type = img.dtype
        img.astype(np.float32)
        if in_img_type != np.uint8:
            img *= 255.
        # convert
        if only_y:
            rlt = np.dot(img, [65.481, 128.553, 24.966]) / 255.0 + 16.0
        else:
            rlt = np.matmul(img, [[65.481, -37.797, 112.0], [128.553, -74.203, -93.786],
                                  [24.966, 112.0, -18.214]]) / 255.0 + [16, 128, 128]
        if in_img_type == np.uint8:
            rlt = rlt.round()
        else:
            rlt /= 255.
        return rlt.astype(in_img_type)

    def calculate_ssim(self, img1, img2):
        '''calculate SSIM
        the same outputs as MATLAB's
        img1, img2: [0, 255]
        '''
        if not img1.shape == img2.shape:
            raise ValueError('Input images must have the same dimensions.')
        if img1.ndim == 2:
            return self.ssim(img1, img2)
        elif img1.ndim == 3:
            if img1.shape[2] == 3:
                ssims = []
                for i in range(3):
                    ssims.append(self.ssim(img1[:, :, i], img2[:, :, i]))
                return np.array(ssims).mean()
            elif img1.shape[2] == 1:
                return self.ssim(np.squeeze(img1), np.squeeze(img2))
        else:
            raise ValueError('Wrong input image dimensions.')

    def calculate_psnr(self, img1, img2, is_kernel=False):
        img1 = img1.astype(np.float64)
        img2 = img2.astype(np.float64)
        mse = np.mean((img1 - img2) ** 2)
        if mse == 0:
            return float('inf')
        return 20 * math.log10(1.0 / math.sqrt(mse)) if is_kernel else 20 * math.log10(255.0 / math.sqrt(mse))

    def evaluation_image(self, hr, sr, sf):

        hr = tensor2im01(hr)
        sr = tensor2im01(sr)
        hr = self.rgb2ycbcr(hr / 255., only_y=True)
        sr = self.rgb2ycbcr(sr / 255., only_y=True)
        crop_border = sf**2
        cropped_sr = sr[crop_border:-crop_border, crop_border:-crop_border]
        hr_11 = (hr.shape[0]-cropped_sr.shape[0])//2
        hr_12 = hr.shape[0] - cropped_sr.shape[0] - hr_11
        hr_21 = (hr.shape[1] - cropped_sr.shape[1]) // 2
        hr_22 = hr.shape[1] - cropped_sr.shape[1] - hr_21
        cropped_hr = hr[hr_11:-hr_12, hr_21:-hr_22]
        im_psnr = self.calculate_psnr(cropped_hr * 255, cropped_sr * 255)
        im_ssim = self.calculate_ssim(cropped_hr * 255, cropped_sr * 255)

        return im_psnr, im_ssim

    def gen_kernel_fixed(self, k_size, scale_factor, lambda_1, lambda_2, theta, noise, move_x, move_y):
        # Set COV matrix using Lambdas and Theta
        LAMBDA = np.diag([lambda_1, lambda_2]);
        Q = np.array([[np.cos(theta), -np.sin(theta)],
                      [np.sin(theta), np.cos(theta)]])
        SIGMA = Q @ LAMBDA @ Q.T
        INV_SIGMA = np.linalg.inv(SIGMA)[None, None, :, :]

        # Set expectation position (shifting kernel for aligned image)
        MU = k_size // 2 + 0.5 * (scale_factor - k_size % 2)
        MU = MU[None, None, :, None]

        # Create meshgrid for Gaussian
        [X, Y] = np.meshgrid(range(k_size[0]), range(k_size[1]))
        Z = np.stack([X, Y], 2)[:, :, :, None]

        # Calcualte Gaussian for every pixel of the kernel
        ZZ = Z - MU
        ZZ_t = ZZ.transpose(0, 1, 3, 2)
        raw_kernel = np.exp(-0.5 * np.squeeze(ZZ_t @ INV_SIGMA @ ZZ)) * (1 + noise)

        # shift the kernel so it will be centered
        raw_kernel_moved = kernel_move(raw_kernel, move_x, move_y)

        # Normalize the kernel and return
        kernel = raw_kernel_moved / np.sum(raw_kernel_moved)
        # kernel = raw_kernel_centered / np.sum(raw_kernel_centered)

        return kernel

    def gen_kernel_random(self, k_size, scale_factor, min_var, max_var, noise_level, move_x, move_y):

        lambda_1 = min_var + np.random.rand() * (max_var - min_var);
        lambda_2 = min_var + np.random.rand() * (max_var - min_var);
        theta = np.random.rand() * np.pi
        noise = -noise_level + np.random.rand(*k_size) * noise_level * 2

        kernel = self.gen_kernel_fixed(k_size, scale_factor, lambda_1, lambda_2, theta, noise, move_x, move_y)

        return kernel

    def rotate(self, image, angle, center=None, scale=1.0):
        # grab the dimensions of the image
        (h, w) = image.shape[:2]

        # if the center is None, initialize it as the center of
        # the image
        if center is None:
            center = (w // 2, h // 2)

        # perform the rotation
        M = cv2.getRotationMatrix2D(center, angle, scale)
        rotated = cv2.warpAffine(image, M, (w, h))

        # return the rotated image
        return rotated

    def drawLine_Basic(self, theta):

        for xi in range(self.kernel_size):
            for yi in range(self.kernel_size):
                M = int((self.sf * 3 + 3) / 2)
                kernel_init = torch.zeros([min(self.sf * 4 + 3, 21), min(self.sf * 4 + 3, 21)]).to(torch.device('cuda'))

    def gen_kernel_motion_fixed(self, theta, noise = 0):

        # kernel_size = min(sf * 4 + 3, 21)
        # kernel_size = k_size[0]
        M = int((self.sf * 3 + 3) / 2)
        kernel_init = np.zeros([min(self.sf * 4 + 3, 21), min(self.sf * 4 + 3, 21)])
        # kernel_init[M-1:M+1,M-len:M-len] = 1
        kernel_init[M:M + 1, M - self.conf.lens + 1:M + self.conf.lens] = 1  # [M-1:M+1, M-lens:M+lens]
        kernel = kernel_init + noise
        center = (M, M)
        kernel = self.rotate(kernel, theta, center, scale=1.0)
        kernel = kernel / np.sum(kernel)

        return kernel

    def ekp_kernel_generator(self, U, kernel_size, sf=4, shift='left'):
        '''
        Generate Gaussian kernel according to cholesky decomposion.
        \Sigma = M * M^T, M is a lower triangular matrix.
        Input:
            U: 2 x 2 torch tensor
            sf: scale factor
        Output:
            kernel: 2 x 2 torch tensor
        '''
        #  Mask
        mask = torch.tensor([[1.0, 0.0],
                             [1.0, 1.0]], dtype=torch.float32).to(U.device)
        M = U * mask

        # Set COV matrix using Lambdas and Theta
        INV_SIGMA = torch.mm(M.t(), M)

        # Set expectation position (shifting kernel for aligned image)
        if shift.lower() == 'left':
            MU = kernel_size // 2 - 0.5 * (sf - 1)
        elif shift.lower() == 'center':
            MU = kernel_size // 2
        elif shift.lower() == 'right':
            MU = kernel_size // 2 + 0.5 * (sf - 1)
        else:
            sys.exit('Please input corrected shift parameter: left , right or center!')

        # Create meshgrid for Gaussian
        X, Y = torch.meshgrid(torch.arange(kernel_size), torch.arange(kernel_size))
        Z = torch.stack((X, Y), dim=2).unsqueeze(3).type(torch.float32).to(U.device)  # k x k x 2 x 1

        # Calcualte Gaussian for every pixel of the kernel
        ZZ = Z - MU
        ZZ_t = ZZ.permute(0, 1, 3, 2)  # k x k x 1 x 2
        raw_kernel = torch.exp(-0.5 * torch.squeeze(ZZ_t.matmul(INV_SIGMA).matmul(ZZ)))

        # Normalize the kernel and return
        kernel = raw_kernel / torch.sum(raw_kernel)  # k x k
        return kernel.unsqueeze(0).unsqueeze(0)

    def ekp_motion_kernel_generator(self, INV_SIGMA, kernel_size, sf=4, shift='left'):
        '''
        Generate Gaussian kernel according to cholesky decomposion.
        \Sigma = M * M^T, M is a lower triangular matrix.
        Input:
            U: 2 x 2 torch tensor
            sf: scale factor
        Output:
            kernel: 2 x 2 torch tensor
        '''
        #  Mask
        # mask = torch.tensor([[1.0, 0.0],
        #                      [1.0, 1.0]], dtype=torch.float32).to(U.device)
        # M = U * mask
        #
        # # Set COV matrix using Lambdas and Theta
        # INV_SIGMA = torch.mm(M.t(), M)

        # Set expectation position (shifting kernel for aligned image)
        if shift.lower() == 'left':
            MU = kernel_size // 2 - 0.5 * (sf - 1)
        elif shift.lower() == 'center':
            MU = kernel_size // 2
        elif shift.lower() == 'right':
            MU = kernel_size // 2 + 0.5 * (sf - 1)
        else:
            sys.exit('Please input corrected shift parameter: left , right or center!')

        # Create meshgrid for Gaussian
        X, Y = torch.meshgrid(torch.arange(kernel_size), torch.arange(kernel_size))
        Z = torch.stack((X, Y), dim=2).unsqueeze(3).type(torch.float32).to(INV_SIGMA.device)  # k x k x 2 x 1

        # Calcualte Gaussian for every pixel of the kernel
        ZZ = Z - MU
        ZZ_t = ZZ.permute(0, 1, 3, 2)  # k x k x 1 x 2
        raw_kernel = torch.exp(-0.5 * torch.squeeze(ZZ_t.matmul(INV_SIGMA).matmul(ZZ)))

        # Normalize the kernel and return
        kernel = raw_kernel / torch.sum(raw_kernel)  # k x k
        return kernel.unsqueeze(0).unsqueeze(0)

    def motion_kernel_generator(self, theta, kernel_size, sf):
        '''
        Generate motion kernel.
        Input:
            theta: motion kernel rotate angle
            sf: scale factor
        Output:
            kernel
        '''

        gen_kernel = self.gen_kernel_motion_fixed(theta)

        return gen_kernel

    def generate_kernel(self):
        if (self.conf.model == 'MLMC'):
            kernel = self.net_kp(self.kernel_code).view(1, 1, self.kernel_size, self.kernel_size)
        elif (self.conf.model == 'MLKPF(SPL)'):
            kernel = self.ekp_kernel_generator(self.kernel_code,
                                               kernel_size=self.kernel_size,
                                               sf=self.sf,
                                               shift="left")

        elif (self.conf.model == 'MLMC(motion-network)'):
            kernel = self.net_kp(self.kernel_code).view(1, 1, self.kernel_size, self.kernel_size)

        elif (self.conf.model == 'MLMC(motion-model)'):

            # kernel = self.motion_kernel_generator(self.kernel_code,
            #                                    kernel_size=self.kernel_size,
            #                                    sf=self.sf)

            for i in range(50):
                a = torch.rand(1)
                b = torch.rand(1)/10
                c = 1
                d = torch.rand(1)/100

                # theta = torch.rand(1)
                # M = int((self.sf * 3 + 3) / 2)
                # center = (M, M)
                #
                # # perform the rotation
                # MM = cv2.getRotationMatrix2D(center, angle, 1.0)

                self.kernel_code.data[0][0] = c
                self.kernel_code.data[1][1] = d
                kernel = self.ekp_motion_kernel_generator(self.kernel_code,
                                                   kernel_size=self.kernel_size,
                                                   sf=self.sf,
                                                   shift="left")

                save_final_kernel_png(move2cpu(kernel.squeeze()), self.conf, move2cpu(kernel.squeeze()),(str(c)+"-"+str(d)))

        return kernel

    def K_optimizer_zero(self):
        self.lossk = 0
        if (self.conf.model == 'MLMC'):
            self.optimizer_kp.zero_grad()
        elif (self.conf.model == 'MLKPF(SPL)'):
            self.optimizer_kernel.zero_grad()
        elif (self.conf.model == 'MLMC(motion-network)'):
            self.optimizer_kp.zero_grad()
        elif (self.conf.model == 'MLMC(motion-model)'):
            self.optimizer_kernel.zero_grad()

    def K_optimizer_update(self):
        if (self.conf.model == 'MLMC'):
            self.optimizer_kp.step()
        elif (self.conf.model == 'MLKPF(SPL)'):
            self.optimizer_kernel.step()
        elif (self.conf.model == 'MLMC(motion-network)'):
            self.optimizer_kp.zero_grad()
        elif (self.conf.model == 'MLMC(motion-model)'):
            self.optimizer_kernel.step()

    def X_optimizer_zero(self):
        self.optimizer_dip.zero_grad()

    def gen_random_Gaussian_kernel(self):

        min_var = 0.175 * self.sf + self.conf.var_min_add
        max_var = min(2.5 * self.sf, 10) + self.conf.var_max_add
        k_size = np.array(
            [min(self.sf * 4 + 3, 21),
             min(self.sf * 4 + 3, 21)])  # 11x11, 15x15, 19x19, 21x21 for x2, x3, x4, x8

        self.kernel_random = self.gen_kernel_random(k_size, self.sf, min_var, max_var, 0, self.conf.kernel_x, self.conf.kernel_y)
        self.kernel_random = torch.from_numpy(self.kernel_random).type(torch.FloatTensor).to(torch.device('cuda')).unsqueeze(
            0).unsqueeze(0)

        return self.kernel_random

    def gen_random_Motion_kernel(self):

        theta = np.random.rand() * 180  # np.pi
        k_size = np.array(
            [min(self.sf * 4 + 3, 21),
             min(self.sf * 4 + 3, 21)])  # 11x11, 15x15, 19x19, 21x21 for x2, x3, x4, x8
        sf = np.array([self.sf, self.sf])
        self.kernel_random = self.gen_kernel_motion_fixed(theta)
        self.kernel_random = torch.from_numpy(self.kernel_random).type(torch.FloatTensor).to(
            torch.device('cuda')).unsqueeze(
            0).unsqueeze(0)
        return self.kernel_random

    def KL_Loss(self, kernel1, kernel2):
        KL_loss = 0.0
        eps =1e-7
        a = kernel1.size()
        [B, C, H, W] = kernel1.size()
        if B == 1 and C == 1:
            for i in range(H):
                for j in range(W):
                            KL_loss += (kernel1[:,:,i,j] + eps) * torch.log((kernel1[:,:,i,j] + eps) / (kernel2[:,:,i,j] + eps))
        return KL_loss

    def __init__(self, conf, lr, hr, device=torch.device('cuda')):

        # Acquire configuration
        self.conf = conf
        self.lr = lr
        self.sf = conf.sf
        self.hr = hr

        # self.kernel_size = min(conf.sf * 4 + 3, 21)
        # kernel _size change (x2)

        self.kernel_size = min(conf.sf * 4 + 3, 21)

        _, C, H, W = self.lr.size()

        # DIP model
        _, C, H, W = self.lr.size()
        self.input_dip = get_noise(C, 'noise', (H * self.sf, W * self.sf)).to(device).detach()
        # self.input_dip = get_noise(C, 'noise', (125, 125)).to(device).detach()
        self.input_dip.requires_grad = False

        if self.conf.DIP_net == "DIP":

            self.net_dip = skip(C, C,
                                num_channels_down=[128, 128, 128, 128, 128],
                                num_channels_up=[128, 128, 128, 128, 128],
                                num_channels_skip=[16, 16, 16, 16, 16],
                                upsample_mode='bilinear',
                                need_sigmoid=True, need_bias=True, pad='reflection', act_fun='LeakyReLU')

        elif self.conf.DIP_net == "DIP_tiny":
            self.net_dip = tiny_skip(num_input_channels=C,
                                 num_output_channels=C,
                                 num_channels_down=[96, 96, 96],
                                 num_channels_up=[96, 96, 96],
                                 num_channels_skip=16,
                                 upsample_mode='bilinear',
                                 need_sigmoid=True,
                                 need_bias=True,
                                 pad='reflection',
                                 act_fun='LeakyReLU',
                                 use_bn=True).cuda()

        self.net_dip = self.net_dip.to(device)
        # print(self.net_dip)
        self.optimizer_dip = torch.optim.Adam([{'params': self.net_dip.parameters()}], lr=conf.dip_lr)

        # loss
        self.ssimloss = SSIM().to(device)
        self.mse = torch.nn.MSELoss().to(device)


        print('*' * 60 + '\nSTARTED {} on: {}...'.format(conf.model, conf.input_image_path))

        log_str = 'Number of parameters in Generator-x: {:.2f}K'
        print(log_str.format(self.calculate_parameters(self.net_dip) / 1000))

        # Meta-learning based Monte Carlo SISR
        if conf.model == 'MLMC':
            n_k = 200
            self.kernel_code = get_noise(n_k, 'noise', (1, 1)).detach().squeeze().to(device)
            self.kernel_code.requires_grad = False
            self.net_kp = fcn(n_k, self.kernel_size ** 2).to(device)
            self.optimizer_kp = torch.optim.Adam([{'params': self.net_kp.parameters()}], lr=9e-5) # 1e-4

            log_str = 'Number of parameters in Generator-k: {:.2f}K'
            print(log_str.format(self.calculate_parameters(self.net_kp) / 1000))

            for i in range( self.conf.kernel_first_iteration):

                # Experiment3 large kernel size sf=2 & kernel_sizeX2

                kernel = self.generate_kernel()
                kernel_random = self.gen_random_Motion_kernel()

                # lossk = self.mse(kernel_random, kernel)
                lossk = self.KL_Loss(kernel_random, kernel)

                lossk.backward(retain_graph=True)
                lossk.detach()

                self.optimizer_kp.step()
                self.optimizer_kp.zero_grad()

        if conf.model == 'MLMC(motion-network)':
            n_k = 200
            self.kernel_code = get_noise(n_k, 'noise', (1, 1)).detach().squeeze().to(device)
            self.kernel_code.requires_grad = False
            self.net_kp = fcn(n_k, self.kernel_size ** 2).to(device)
            self.optimizer_kp = torch.optim.Adam([{'params': self.net_kp.parameters()}], lr=9e-5) # 1e-4

            log_str = 'Number of parameters in Generator-k: {:.2f}K'
            print(log_str.format(self.calculate_parameters(self.net_kp) / 1000))

            for i in range( self.conf.kernel_first_iteration):

                # Experiment3 large kernel size sf=2 & kernel_sizeX2

                kernel = self.generate_kernel()
                kernel_random = self.gen_random_Motion_kernel()

                lossk = self.mse(kernel_random, kernel)
                # lossk = self.KL_Loss(kernel_random, kernel)

                lossk.backward(retain_graph=True)
                lossk.detach()

                self.optimizer_kp.step()
                self.optimizer_kp.zero_grad()

        if conf.model == 'MLKPF(SPL)':

            # E Kernel Prior
            l1 = 1 / (self.sf * 1.00)
            self.kernel_code = torch.tensor([[l1, 0.0],
                                             [0.0, l1]], dtype=torch.float32).cuda()
            self.kernel_code.requires_grad = True
            self.optimizer_kernel = optim.Adam(params=[self.kernel_code, ], lr=5e-3)

        if conf.model == 'MLMC(motion-model)':
            # E Kernel Prior
            l1 = 1 / (self.sf * 1.00)
            self.kernel_code = torch.tensor([[l1, 0.0],
                                             [0.0, l1]], dtype=torch.float32).cuda()
            self.kernel_code.requires_grad = True
            self.optimizer_kernel = optim.Adam(params=[self.kernel_code, ], lr=5e-3)

        fold = '../data/Tensorboard'
        TB_model = self.conf.model + self.conf.model_num
        self.writer_model = SummaryWriter(log_dir=os.path.join(fold, TB_model), flush_secs=20)

        _, C, H, W = self.lr.size()

        self.D_loop = self.conf.D_loop
        self.I_loop_x = self.conf.I_loop_x
        self.I_loop_k = self.conf.I_loop_k


        self.lagd_y = F.interpolate(self.lr, size=[H * self.sf, W * self.sf], mode='bicubic', align_corners=False)
        path = os.path.join(self.conf.input_dir, self.conf.filename).replace('lr_x', 'gt_k_x').replace('.png', '.mat')

        if self.conf.real == False:
            self.kernel_gt = sio.loadmat(path)['Kernel']
        else:
            self.kernel_gt = np.zeros([self.kernel_size, self.kernel_size])

        self.make_gradient_filter()

        self.num_pixels = self.lr.numel()
        self.lambda_p = torch.ones_like(self.lr, requires_grad=False) * (0.01 ** 2)
        self.noise2_mean = 1







    '''
    # ---------------------
    # (2) training
    # ---------------------
    '''

    def train(self):


        for iteration in tqdm.tqdm(range(self.conf.max_iters), ncols=60):

            if self.conf.model == 'ISARDIP':
                # if iteration == 0:
                #     # kernel_ = torch.softmax(self.kernel_code, 0).view(1, 1, self.kernel_size, self.kernel_size)
                #     kernel = kernel_gt
                #     device = torch.device('cuda')
                #     kernel = torch.FloatTensor(kernel).unsqueeze(0).unsqueeze(0).to(device)

                self.optimizer_dip.zero_grad()
                sr = self.net_dip(self.input_dip)
                sr_pad = F.pad(sr, mode='circular',
                               pad=(self.kernel_size // 2, self.kernel_size // 2, self.kernel_size // 2,
                                    self.kernel_size // 2))

                out = F.conv2d(sr_pad, kernel.expand(3, -1, -1, -1).clone().detach(), groups=3)
                # out = sr
                out = out[:, :, 0::self.sf, 0::self.sf]
                loss = self.mse(out, self.lr)
                loss.backward(retain_graph=True)
                loss.detach()
                self.optimizer_dip.step()

                if (iteration + 1) == self.conf.max_iters:

                    save_final_kernel_png(move2cpu(kernel.squeeze()), self.conf, self.conf.kernel_gt, iteration)
                    plt.imsave(os.path.join(self.conf.output_dir_path, '{}_{}.png'.format(self.conf.img_name, iteration)),
                               tensor2im01(sr), vmin=0, vmax=1., dpi=1)

                    image_psnr, image_ssim = self.evaluation_image(self.hr, sr, self.sf)

                    print('\n Iter {}, loss: {}, PSNR: {}, SSIM: {}'.format(iteration, loss.data, image_psnr, image_ssim))

                    writer_model.add_scalar('Image_PSNR/' + self.conf.img_name, image_psnr,
                                            (iteration))
                    writer_model.add_scalar('RE_loss/' + self.conf.img_name, loss.data, (iteration))
                    # writer_model.add_scalar('Kernel_PSNR/' + self.conf.img_name, kernel_psnr,
                    #                         (iteration * I_loop_x + i_p))

                    sheet.write((iteration) + 1, col1, '%.2f' % image_psnr, black_style)
                    wb.save(self.conf.output_dir_path + "/" + self.conf.img_name + '.xls')
                    sheet.write((iteration) + 1, col2, '%.2f' % loss.data, black_style)
                    wb.save(self.conf.output_dir_path + "/" + self.conf.img_name + '.xls')
                    # sheet.write((iteration * I_loop_x + i_p) + 1, col3, '%.2f' % kernel_psnr, black_style)
                    # wb.save(self.conf.model_num + '.xls')

            else:
                raise ValueError('Wrong input model name.')



        kernel = move2cpu(kernel.squeeze())

        save_final_kernel_png(kernel, self.conf, self.conf.kernel_gt)

        if self.conf.verbose:
            print('{} estimation complete! (see --{}-- folder)\n'.format(self.conf.model,
                                                                         self.conf.output_dir_path) + '*' * 60 + '\n\n')

        return kernel, sr


class SphericalOptimizer(torch.optim.Optimizer):
    ''' spherical optimizer, optimizer on the sphere of the latent space'''

    def __init__(self, kernel_size, optimizer, params, **kwargs):
        self.opt = optimizer(params, **kwargs)
        self.params = params
        with torch.no_grad():
            # in practice, setting the radii as kernel_size-1 is slightly better
            self.radii = {param: torch.ones([1, 1, 1]).to(param.device) * (kernel_size - 1) for param in params}

    @torch.no_grad()
    def step(self, closure=None):
        loss = self.opt.step(closure)
        for param in self.params:
            param.data.div_((param.pow(2).sum(tuple(range(2, param.ndim)), keepdim=True) + 1e-9).sqrt())
            param.mul_(self.radii[param])

        return loss

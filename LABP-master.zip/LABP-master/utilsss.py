def DFT2D(x, shift=True):
    '''
    Discrete space fourier transform
    x: Input matrix
    '''
    pi2 = 2*np.pi
    N1, N2 = x.shape
    X = np.zeros((N1, N2), dtype=np.complex64)
    n1, n2 = np.mgrid[0:N1, 0:N2]

    for w1 in range(N1):
        for w2 in range(N2):
            j2pi = np.zeros((N1, N2), dtype=np.complex64)
            j2pi.imag = pi2*(w1*n1/N1 + w2*n2/N2)
            X[w1, w2] = np.sum(x*np.exp(-j2pi))
    if shift:
        X = np.roll(X, N1//2, axis=0)
        X = np.roll(X, N2//2, axis=1)
    return X

def DFT(sig):
    N = sig.size
    V = np.array([[np.exp(-1j*2*np.pi*v*y/N) for v in range(N)] for y in range(N)])
    return sig.dot(V)

def FFT(x):
    N = x.shape[1] # 只需考虑第二个维度，然后在第一个维度循环
    if N % 2 > 0:
        raise ValueError("size of x must be a power of 2")
    elif N <= 8:  # this cutoff should be optimized
        return np.array([DFT(x[i,:]) for i in range(x.shape[0])])
    else:
        X_even = FFT(x[:,::2])
        X_odd = FFT(x[:,1::2])
        factor = np.array([np.exp(-2j * np.pi * np.arange(N) / N) for i in range(x.shape[0])])
        return np.hstack([X_even + np.multiply(factor[:,:int(N/2)],X_odd),
                               X_even + np.multiply(factor[:,int(N/2):],X_odd)])

def FFT2D(img):
    return FFT(FFT(img).T).T
#
def FFT_SHIFT(img):
    M,N = img.shape
    M = int(M/2)
    N = int(N/2)
    return np.vstack((np.hstack((img[M:,N:],img[M:,:N])),np.hstack((img[:M,N:],img[:M,:N]))))

#
# # RDimage_full.numpy()
# my_fft = abs(FFT_SHIFT(FFT2D(hrrp)))
# save_imagesc_mat2png(abs(my_fft), output_dir_path, filename + "_my_fft")


def FFT_check(x):#用0将x的长度补齐到2的幂
    x.extend([0 for i in range(2 ** (int(np.ceil(np.log(len(x), 2)))) - len(x))])
    return np.array(x)

def FFT_order(x):#此处改自他人代码用于为输入排序
    num = len(x)
    j = num // 2
    for i in range(1, num - 2):
        if (i < j):
            x[i], x[j] = x[j], x[i]
        k = num / 2
        while (j >= k):
            j -= k
            k /= 2
        j = int(j + k)

def FFT(x):
    N = len(x)
    num = N // 2
    M = int(np.log(N,2))
    if N != 2:
        x = np.append(FFT(x[:num]),FFT(x[num:]))
    else:
        print("当前层数：",M)#Debug用
        print("初始",x)#Debug用
        k = x[1]
        x[1] = x[0]-k
        x[0] += k
        print("结束",x)#Debug用
        return x
    print("当前层数：", M)#Debug用
    print("初始", x)#Debug用
    for unit in range(num):
        #a = x[unit]
        #b = x[unit+1 << (M-1)]
        #W = complex(cos(2 * pi * unit / 1 << M), -sin(2 * pi * unit / 1 << M))
        #k = b*W
        k = x[unit+(1 << (M-1))]*complex(np.cos(2 * np.pi * unit / (1 << M)), -np.sin(2 * np.pi * unit / (1 << M)))#左移运算符的优先级好像比加号低，尴尬
        x[unit + (1 << (M - 1))] = x[unit] - k
        x[unit] += k
    print("结束", x)#Debug用
    return x

def IFFT(X):
    N = len(X)
    num = N // 2
    M = int(np.log(N,2))
    if N != 2:
        X = np.append(IFFT(X[:num]), IFFT(X[num:]))
        print(X)
    else:
        print("当前层数：",M)#Debug用
        print("初始",X)#Debug用
        k = X[1]
        X[1] = X[0]-k
        X[0] += k
        print("结束",X)#Debug用
        return X/2#这个2相当于DFT里最后除的N
    print("当前层数：", M)#Debug用
    print("初始", X)#Debug用
    for unit in range(num):
        #a = x[unit]
        #b = x[unit+1 << (M-1)]
        #W = complex(cos(2 * pi * unit / 1 << M), -sin(2 * pi * unit / 1 << M))
        #k = b*W
        k = X[unit+(1 << (M-1))]*complex(np.cos(2 * np.pi * unit / (1 << M)), np.sin(2 * np.pi * unit / (1 << M)))#左移运算符的优先级好像比加号低，尴尬
        X[unit + (1 << (M - 1))] = X[unit] - k
        X[unit] += k
    print("结束", X)#Debug用
    return X/2#这个2相当于DFT里最后除的N

def FFT2D(x):
    N2 = len(x)#获取行数，即y值
    N1 = len(x[0])#获取列数，即x值
    for k2 in range(N2):#遍历X中的行
        FFT(x[k2])
    for k1 in range(N1):  # 遍历X中的列
        FFT(x[:, k1])
    return x

def IFFT2D(X):
    N2 = len(X)#获取行数，即y值
    N1 = len(X[0])#获取列数，即x值
    for n2 in range(N2):#遍历x中的行
        IFFT(X[n2])
    for n1 in range(N1):  # 遍历x中的列
        IFFT(X[:,n1])
    #x /= N1*N2#因为在IFFT中我们已经对数据进行过这一步处理，所以这里就不需要处理了
    return X
